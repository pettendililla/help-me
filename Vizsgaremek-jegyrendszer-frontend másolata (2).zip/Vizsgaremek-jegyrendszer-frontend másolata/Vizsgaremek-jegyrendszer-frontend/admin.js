
document.addEventListener("DOMContentLoaded", async () => {
  if (!window.Api.isLoggedIn()) {
    window.location.href = "bejelentkezes.html";
    return;
  }
  if (window.Api.getRole() !== "ADMIN") {
    window.location.href = "bejelentkezes.html";
    return;
  }

  const loggedNameEl = document.getElementById("loggedName");
  if (loggedNameEl) loggedNameEl.textContent = window.Api.getName() || "Admin";

  const logoutBtn = document.getElementById("logoutBtn");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", (e) => {
      e.preventDefault();
      window.Api.logout("jegyfoglalo.html");
    });
  }

  document.addEventListener("click", async (e) => {
    const btn = e.target.closest(".deleteUserBtn");
    if (!btn) return;

    const id = btn.getAttribute("data-user-id");
    if (!id) return;

    if (!confirm("Biztos törlöd a felhasználót?")) return;

    try {
      await window.Api.adminDeleteUser(id);
      alert("Törölve.");
      window.location.reload();
    } catch (err) {
      alert("Hiba: " + err.message);
    }
  });
});