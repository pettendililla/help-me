document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("registerForm");
  const nameInput = document.getElementById("name");
  const emailInput = document.getElementById("email");
  const pw1 = document.getElementById("password");
  const pw2 = document.getElementById("password2");

  const btn = document.getElementById("registerBtn");
  const spinner = document.getElementById("registerSpinner");
  const messageEl = document.getElementById("message");
  const pwHint = document.getElementById("pwHint");

  function setMessage(text, type = "danger") {
    messageEl.innerHTML = text
      ? `<div class="alert alert-${type} py-2 mb-0">${text}</div>`
      : "";
  }

  function setPwHint(text, ok) {
    if (!pwHint) return;
    pwHint.textContent = text || "";
    pwHint.style.color = ok ? "green" : "#7a0000";
  }

  document.getElementById("togglePassword").addEventListener("click", () => {
    const isPw = pw1.type === "password";
    pw1.type = isPw ? "text" : "password";
    document.getElementById("togglePassword").innerHTML = isPw
      ? '<i class="bi bi-eye-slash"></i>'
      : '<i class="bi bi-eye"></i>';
  });

  document.getElementById("togglePassword2").addEventListener("click", () => {
    const isPw = pw2.type === "password";
    pw2.type = isPw ? "text" : "password";
    document.getElementById("togglePassword2").innerHTML = isPw
      ? '<i class="bi bi-eye-slash"></i>'
      : '<i class="bi bi-eye"></i>';
  });

  function checkPasswords() {
    const a = (pw1.value || "").trim();
    const b = (pw2.value || "").trim();
    if (!a || !b) {
      setPwHint("", true);
      return true;
    }
    if (a !== b) {
      setPwHint("A két jelszó nem egyezik!", false);
      return false;
    }
    setPwHint("A jelszavak egyeznek.", true);
    return true;
  }
  pw1.addEventListener("input", checkPasswords);
  pw2.addEventListener("input", checkPasswords);

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    e.stopPropagation();

    if (!form.checkValidity()) {
      form.classList.add("was-validated");
      return;
    }

    if (!checkPasswords()) {
      setMessage("Hiba: a két jelszó nem egyezik!", "danger");
      return;
    }

    setMessage("");

    const name = (nameInput.value || "").trim();
    const email = (emailInput.value || "").trim();
    const password = (pw1.value || "").trim();

    try {
      btn.disabled = true;
      spinner.classList.remove("d-none");

      await window.Api.register(name, email, password);

      setMessage("Sikeres regisztráció! Most jelentkezz be.", "success");

      setTimeout(() => {
        window.location.href = "bejelentkezes.html";
      }, 700);

    } catch (err) {
      setMessage("Hiba: " + (err?.message ?? "Ismeretlen hiba"), "danger");
    } finally {
      btn.disabled = false;
      spinner.classList.add("d-none");
    }
  });
});