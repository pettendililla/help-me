document.addEventListener("DOMContentLoaded", () => {
  console.log("JS elindult");

  const form = document.getElementById("loginForm");
  const nameInput = document.getElementById("name");
  const emailInput = document.getElementById("email");
  const passInput = document.getElementById("password");
  const spinner = document.getElementById("loginSpinner");
  const loginBtn = document.getElementById("loginBtn");
  const messageEl = document.getElementById("message");
  const togglePassword = document.getElementById("togglePassword");

  console.log({
    form,
    nameInput,
    emailInput,
    passInput,
    spinner,
    loginBtn,
    messageEl,
    togglePassword
  });

  function setMessage(text, type = "danger") {
    messageEl.innerHTML = text
      ? `<div class="alert alert-${type} py-2 mb-0">${text}</div>`
      : "";
  }

  if (togglePassword) {
    togglePassword.addEventListener("click", () => {
      const isPw = passInput.type === "password";
      passInput.type = isPw ? "text" : "password";
      togglePassword.innerHTML = isPw
        ? '<i class="bi bi-eye-slash"></i>'
        : '<i class="bi bi-eye"></i>';
    });
  }

  loginBtn.addEventListener("click", async (e) => {
    console.log("KATTINTÁS LEFUTOTT");
    e.preventDefault();

    if (!form.checkValidity()) {
      form.classList.add("was-validated");
      return;
    }

    setMessage("");

    const email = emailInput.value.trim();
    const password = passInput.value.trim();

    try {
      loginBtn.disabled = true;
      spinner.classList.remove("d-none");

      const data = await window.Api.login(email, password);

      if (data.role === "ADMIN") {
        window.location.href = "admin.html";
      } else {
        window.location.href = "profil.html";
      }
    } catch (err) {
      setMessage("Hiba: " + (err?.message ?? "Ismeretlen hiba"), "danger");
      console.error(err);
    } finally {
      loginBtn.disabled = false;
      spinner.classList.add("d-none");
    }
  });
});