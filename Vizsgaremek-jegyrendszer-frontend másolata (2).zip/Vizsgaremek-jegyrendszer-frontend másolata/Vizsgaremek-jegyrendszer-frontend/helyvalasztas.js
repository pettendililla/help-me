let selectedSeats = [];

document.addEventListener("DOMContentLoaded", () => {

  const params = new URLSearchParams(window.location.search);
  const title = params.get("title");

  if(title){
    const titleEl = document.getElementById("showTitle");
    if(titleEl){
      titleEl.innerText = decodeURIComponent(title);
    }
  }

  generateSeats();
});

function generateSeats(){
  const container = document.getElementById("seats");

  if(!container){
    console.error("Nincs seats div!");
    return;
  }

  for(let i = 0; i < 5; i++){
    let row = document.createElement("div");
    row.className = "d-flex justify-content-center";

    for(let j = 0; j < 10; j++){
      let seat = document.createElement("div");
      seat.className = "seat";

      seat.onclick = () => toggleSeat(seat, i, j);

      row.appendChild(seat);
    }

    container.appendChild(row);
  }
}

function toggleSeat(seat, row, col){

  if(seat.classList.contains("taken")) return;

  seat.classList.toggle("selected");

  const id = row + "-" + col;

  if(selectedSeats.includes(id)){
    selectedSeats = selectedSeats.filter(s => s !== id);
  } else {
    selectedSeats.push(id);
  }
}

async function foglalSeat(){

  if(selectedSeats.length === 0){
    alert("Válassz helyet!");
    return;
  }

  const params = new URLSearchParams(window.location.search);
  const showId = params.get("showId");

  try{
    await Api.saveSeats({
      showId: showId,
      seats: selectedSeats.join(",")
    });

    alert("Helyek lefoglalva!");

  } catch(e){
    alert("Hiba: " + e.message);
  }
}