document.addEventListener("DOMContentLoaded", async () => {
  try {
    const weekly = await Api.getWeekly();

    const container = document.getElementById("moviesContainer");
    container.innerHTML = "";

    weekly.forEach(item => {
      container.innerHTML += `
        <div class="col-md-3 text-center">

          <img src="${item.image_url}" 
               class="img-fluid rounded shadow mb-2">

          <h5>${item.title}</h5>

        </div>
      `;
    });

  } catch (err) {
    console.error(err);
    alert("Hiba a heti ajánló betöltésekor!");
  }
});