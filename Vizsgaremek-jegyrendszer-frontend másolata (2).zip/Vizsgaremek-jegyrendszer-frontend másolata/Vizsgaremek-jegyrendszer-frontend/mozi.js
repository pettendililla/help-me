let movies = [];
let currentIndex = 0;

document.addEventListener("DOMContentLoaded", async () => {
  try {
    movies = await Api.getShows("cinema");

    if (!movies || movies.length === 0) {
      alert("Nincs film!");
      return;
    }

    showMovie(currentIndex);

    document.getElementById("nextBtn").onclick = nextMovie;
    document.getElementById("prevBtn").onclick = prevMovie;

  } catch (err) {
    console.error(err);
    alert("Hiba a mozi betöltésekor!");
  }
});

function showMovie(index) {
  const item = movies[index];

  document.getElementById("title").innerText = item.title;
  document.getElementById("desc").innerText = item.description;

  document.getElementById("poster").src =
    item.image_url || "images/placeholder.png";

   document.getElementById("buyBtn").href =
  `jegyfoglalas.html?id=${item.id}&title=${encodeURIComponent(item.title)}`; 
}

function nextMovie() {
  currentIndex = (currentIndex + 1) % movies.length;
  showMovie(currentIndex);
}

function prevMovie() {
  currentIndex = (currentIndex - 1 + movies.length) % movies.length;
  showMovie(currentIndex);
}