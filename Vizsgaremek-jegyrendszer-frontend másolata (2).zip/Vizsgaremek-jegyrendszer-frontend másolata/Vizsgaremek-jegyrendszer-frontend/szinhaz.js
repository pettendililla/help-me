let theatres = [];
let currentIndex = 0;

document.addEventListener("DOMContentLoaded", async () => {
  try {
    theatres = await Api.getShows("theatre");

    if (!theatres || theatres.length === 0) {
      alert("Nincs színházi előadás!");
      return;
    }

    showTheatre(currentIndex);

    document.getElementById("nextBtn").onclick = nextTheatre;
    document.getElementById("prevBtn").onclick = prevTheatre;

  } catch (err) {
    console.error(err);
    alert("Hiba a színház betöltésekor!");
  }
});

function showTheatre(index) {
  const item = theatres[index];

  console.log("ITEM:", item);
  console.log("ID:", item.id);

  document.getElementById("title").innerText = item.title;
  document.getElementById("desc").innerText = item.description;
  document.getElementById("poster").src = item.image_url || "images/placeholder.png";

  document.getElementById("buyBtn").href =
  `jegyfoglalas.html?id=${item.id}&title=${encodeURIComponent(item.title)}`;
}
function nextTheatre() {
  currentIndex = (currentIndex + 1) % theatres.length;
  showTheatre(currentIndex);
}

function prevTheatre() {
  currentIndex = (currentIndex - 1 + theatres.length) % theatres.length;
  showTheatre(currentIndex);
}