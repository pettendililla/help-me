(() => {
  const BASE_URL = "http://localhost:9090"; 

  function getToken() {
    return sessionStorage.getItem("token");
  }

  function isLoggedIn() {
    return !!getToken();
  }

  function getRole() {
    return sessionStorage.getItem("role");
  }

  function getName() {
    return sessionStorage.getItem("name");
  }

  function logout(redirectTo = "index.html") {
    sessionStorage.removeItem("token");
    sessionStorage.removeItem("role");
    sessionStorage.removeItem("userId");
    sessionStorage.removeItem("name");
    sessionStorage.removeItem("email");
    window.location.href = redirectTo;
  }

  async function apiRequest(path, { method = "GET", body = null, auth = true } = {}) {
    const headers = { "Content-Type": "application/json" };

    if (auth) {
      const token = getToken();
      if (!token) throw new Error("Not logged in");
      headers["Authorization"] = "Bearer " + token;
    }

    const res = await fetch(BASE_URL + path, {
      method,
      mode: "cors",
      headers,
      body: body ? JSON.stringify(body) : null
    });

    const text = await res.text();
    let data = null;
    try {
      data = text ? JSON.parse(text) : null;
    } catch {
      data = text;
    }

    if (!res.ok) {
      const msg = (data && data.error) ? data.error : ("HTTP " + res.status);
      throw new Error(msg);
    }

    return data;
  }

  async function login(email, password) {
    const data = await apiRequest("/api/auth/login", {
      method: "POST",
      body: { email, password },
      auth: false
    });

    sessionStorage.setItem("token", data.token);
    sessionStorage.setItem("role", data.role);
    sessionStorage.setItem("userId", String(data.userId));
    sessionStorage.setItem("name", data.name);
    sessionStorage.setItem("email", data.email);

    return data;
  }

  async function register(name, email, password) {
    return apiRequest("/api/auth/register", {
      method: "POST",
      body: { name, email, password },
      auth: false
    });
  }

  async function getEvents() {
    return apiRequest("/api/events", { auth: false });
  }

  async function getMovies() {
    return apiRequest("/api/movies", { auth: false });
  }

  async function getTheatres() {
    return apiRequest("/api/theatres", { auth: false });
  }

  async function getTickets(eventId) {
    return apiRequest(`/api/tickets?eventId=${encodeURIComponent(eventId)}`, { auth: false });
  }

  async function reserveTicket(ticketId) {
    return apiRequest("/api/tickets/reserve", {
      method: "POST",
      body: { ticketId },
      auth: true
    });
  }

  async function buyTicket(ticketId) {
    return apiRequest("/api/tickets/buy", {
      method: "POST",
      body: { ticketId },
      auth: true
    });
  }

  async function cancelTicket(ticketId) {
    return apiRequest("/api/tickets/cancel", {
      method: "POST",
      body: { ticketId },
      auth: true
    });
  }

  async function adminDeleteUser(id) {
    return apiRequest(`/api/admin/users?id=${encodeURIComponent(id)}`, {
      method: "DELETE",
      auth: true
    });
  }

  async function getWeekly() {
  return apiRequest("/api/weekly", { auth: false });
}

async function getShows(type) {
  return apiRequest(`/api/shows?type=${type}`, { auth: false });
}

  window.Api = {
    isLoggedIn, getRole, getName, logout,
    login, register,
    getEvents, getMovies, getTheatres, getTickets,
    reserveTicket, buyTicket, cancelTicket,
    adminDeleteUser, getWeekly, getShows, apiRequest,   

    saveSeats: async (data) => {
  return apiRequest("/api/seats", {
    method: "POST",
    body: data,
    auth: false
  });
}
  };
})();