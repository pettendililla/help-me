async function foglalas(){
  const params = new URLSearchParams(window.location.search);
  const showId = params.get("id");

  const fullName = document.getElementById("name").value;
  const phone = document.getElementById("phone").value;
  const email = document.getElementById("email").value;
  const paymentMethod = document.querySelector('input[name="payment"]:checked').value;

  try{
    await Api.apiRequest("/api/bookings", {
      method: "POST",
      body: {
        showId,
        fullName,
        phone,
        email,
        paymentMethod
      },
      auth: false
    });

    alert("Foglalás sikeres!");

  }catch(e){
    alert("Hiba: " + e.message);
  }
}

document.addEventListener("DOMContentLoaded", () => {

  const params = new URLSearchParams(window.location.search);
  const title = params.get("title");

  if(title){
    document.getElementById("showTitle").innerText = decodeURIComponent(title);
  }

});