package controller;

import model.Booking;
import model.Event;
import model.User;

public class BookingController {

    public Booking createBooking(User user, Event event, int seats) {
        if (user == null) {
            throw new IllegalArgumentException("User nem lehet null");
        }
        if (event == null) {
            throw new IllegalArgumentException("Event nem lehet null");
        }
        if (seats <= 0) {
            throw new IllegalArgumentException("A foglalt helyek száma legyen pozitív");
        }

        return new Booking(0, user, event, seats);
    }
}
