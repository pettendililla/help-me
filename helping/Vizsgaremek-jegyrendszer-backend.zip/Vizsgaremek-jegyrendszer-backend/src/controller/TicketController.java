package controller;

import dao.TicketDao;
import model.Ticket;
import java.util.List;

public class TicketController {

    private final TicketDao ticketDao;

    public TicketController(TicketDao ticketDao) {
        this.ticketDao = ticketDao;
    }

    
    public List<Ticket> listTicketsForEvent(int eventId) {
        return ticketDao.listForEvent(eventId);
    }

    
    public boolean reserveTicket(int ticketId) {
        return ticketDao.markReserved(ticketId);
    }

    
    public boolean buyTicket(int ticketId) {
        return ticketDao.markSold(ticketId);
    }

    
    public boolean cancelReservation(int ticketId) {
        return ticketDao.cancelReservation(ticketId);
    }

   
    public List<Ticket> getAllFiltered(int eventId, String status) {
        return ticketDao.getAllFiltered(eventId, status);
    }

    
    public boolean deleteTicketById(int id) {
        return ticketDao.deleteById(id);
    }
}