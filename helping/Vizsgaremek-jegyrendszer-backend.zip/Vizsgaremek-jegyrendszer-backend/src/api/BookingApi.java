package api;

import controller.BookingController;
import controller.EventController;
import dao.EventDao;
import model.Booking;
import model.Event;
import model.User;

public class BookingApi {
    private final EventController eventController;
    private final BookingController bookingController;

    public BookingApi() {
        this(new EventController(new EventDao()), new BookingController());
    }

    public BookingApi(EventController eventController, BookingController bookingController) {
        this.eventController = eventController;
        this.bookingController = bookingController;
    }

    public Booking bookTicket(int eventId, int seatCount) {
        User user = new User(1, "Teszt Elek", "teszt@email.hu");
        Event event = eventController.findEventById(eventId);

        if (event == null) {
            throw new IllegalArgumentException("Nincs ilyen esemény");
        }

        return bookingController.createBooking(user, event, seatCount);
    }
}
