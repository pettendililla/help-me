package server;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import dao.BookingDao;
import dao.EventDao;
import dao.TicketDao;
import dao.TheaterDao;
import dao.UserDao;

import model.Event;
import model.MovieDto;
import model.Theater;
import model.Ticket;
import model.User;
import model.ShowDto;

import security.JwtUtil;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.List;

import java.util.*;
import java.sql.*;
import database.Database;

import java.util.Map;
import java.util.HashMap;

public class RestServer {

    public static void main(String[] args) throws Exception {

        // DAO-k
        UserDao userDao = new UserDao();
        EventDao eventDao = new EventDao();
        TicketDao ticketDao = new TicketDao();
        BookingDao bookingDao = new BookingDao();
        TheaterDao theaterDao = new TheaterDao();

        // HTTP szerver
        HttpServer server = HttpServer.create(new InetSocketAddress(9090), 0);

        // ==============================
        // AUTH - LOGIN
        // POST /api/auth/login
        // body: {"email":"...","password":"..."}
        // ==============================
        server.createContext("/api/auth/login", ex -> {
            cors(ex);
            if (isOptions(ex)) return;

            if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
                sendJson(ex, 405, "{\"error\":\"Method not allowed\"}");
                return;
            }

            String body = readBody(ex);
            String email = jsonStr(body, "email");
            String password = jsonStr(body, "password");

            email = email == null ? null : email.trim();
            password = password == null ? null : password.trim();

            if (email == null || password == null) {
                sendJson(ex, 400, "{\"error\":\"Missing email or password\"}");
                return;
            }

            try {
                User dbUser = userDao.findByEmail(email);

                if (dbUser == null || !password.equals(dbUser.getPassword())) {
                    sendJson(ex, 401, "{\"error\":\"Bad credentials\"}");
                    return;
                }

                String token = JwtUtil.generateToken(dbUser.getEmail(), dbUser.getRole().name());

                String resp = "{"
                        + "\"token\":\"" + esc(token) + "\","
                        + "\"role\":\"" + esc(dbUser.getRole().name()) + "\","
                        + "\"userId\":" + dbUser.getId() + ","
                        + "\"name\":\"" + esc(dbUser.getName()) + "\","
                        + "\"email\":\"" + esc(dbUser.getEmail()) + "\""
                        + "}";

                sendJson(ex, 200, resp);

            } catch (Exception e) {
                e.printStackTrace();
                sendJson(ex, 500, "{\"error\":\"Server error\"}");
            }
        });
        
        server.createContext("/api/auth/register", ex -> {
    cors(ex);
    if (isOptions(ex)) return;

    if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
        sendJson(ex, 405, "{\"error\":\"Method not allowed\"}");
        return;
    }

    String body = readBody(ex);
    String name = jsonStr(body, "name");
    String email = jsonStr(body, "email");
    String password = jsonStr(body, "password");

    name = name == null ? null : name.trim();
    email = email == null ? null : email.trim();
    password = password == null ? null : password.trim();

    if (name == null || email == null || password == null ||
        name.isEmpty() || email.isEmpty() || password.isEmpty()) {
        sendJson(ex, 400, "{\"error\":\"Missing fields\"}");
        return;
    }

    try {
        User existing = userDao.findByEmail(email);
        if (existing != null) {
            sendJson(ex, 409, "{\"error\":\"Ez az email már foglalt\"}");
            return;
        }

        boolean ok = userDao.createUser(email, password, name, "user");

        if (!ok) {
            sendJson(ex, 500, "{\"error\":\"Sikertelen regisztráció\"}");
            return;
        }

        sendJson(ex, 201, "{\"message\":\"Sikeres regisztráció\"}");
    } catch (Exception e) {
        e.printStackTrace();
        sendJson(ex, 500, "{\"error\":\"Server error\"}");
    }
});
        
        server.createContext("/api/profile", ex -> {
    cors(ex);
    if (isOptions(ex)) return;

    JwtUtil.DecodedToken jwt = requireJwt(ex);
    Integer userId = getRequiredUserId(jwt, userDao);

    if ("GET".equalsIgnoreCase(ex.getRequestMethod())) {
        User user = userDao.findById(userId);
        if (user == null) {
            sendJson(ex, 404, "{\"error\":\"User not found\"}");
            return;
        }
        sendJson(ex, 200, profileToJson(user));
        return;
    }

    if ("PUT".equalsIgnoreCase(ex.getRequestMethod())) {
        String body = readBody(ex);
        String fullName = jsonStr(body, "fullName");
        String userName = jsonStr(body, "userName");
        String phone = jsonStr(body, "phone");
        String email = jsonStr(body, "email");

        if (fullName == null || fullName.isBlank() || email == null || email.isBlank()) {
            sendJson(ex, 400, "{\"error\":\"Hiányzó kötelező mezők\"}");
            return;
        }

        User existingByEmail = userDao.findByEmail(email.trim());
        if (existingByEmail != null && existingByEmail.getId() != userId) {
            sendJson(ex, 409, "{\"error\":\"Ez az email már foglalt\"}");
            return;
        }

        boolean ok = userDao.updateProfile(userId,
                fullName.trim(),
                userName == null ? null : userName.trim(),
                phone == null ? null : phone.trim(),
                email.trim());

        if (!ok) {
            sendJson(ex, 500, "{\"error\":\"Sikertelen mentés\"}");
            return;
        }

        User updated = userDao.findById(userId);
        sendJson(ex, 200, profileToJson(updated));
        return;
    }

    sendJson(ex, 405, "{\"error\":\"Method not allowed\"}");
});
        
        server.createContext("/api/weekly", ex -> {
    cors(ex);
    if (isOptions(ex)) return;

    if (!"GET".equalsIgnoreCase(ex.getRequestMethod())) {
        sendJson(ex, 405, "{\"error\":\"Method not allowed\"}");
        return;
    }

    List<Map<String, Object>> list = new ArrayList<>();

    try (Connection conn = Database.getConnection();
         PreparedStatement stmt = conn.prepareStatement(
             "SELECT title, image_url FROM weekly_recommendations ORDER BY sort_order"
         );
         ResultSet rs = stmt.executeQuery()) {

        while (rs.next()) {
            Map<String, Object> item = new HashMap<>();
            item.put("title", rs.getString("title"));
            item.put("image_url", rs.getString("image_url"));
            list.add(item);
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    sendJson(ex, 200, weeklyToJson(list));
});
        
        server.createContext("/api/shows", ex -> {
    cors(ex);
    if (isOptions(ex)) return;

    if (!"GET".equalsIgnoreCase(ex.getRequestMethod())) {
        sendJson(ex, 405, "{\"error\":\"Method not allowed\"}");
        return;
    }

    String query = ex.getRequestURI().getQuery();
    String type = null;

    if (query != null && query.contains("type=")) {
        type = query.split("type=")[1];
    }

    List<ShowDto> list = new ArrayList<>();

    try (Connection conn = Database.getConnection()) {

        String sql = "SELECT id, title, description, image_url FROM shows";
        if (type != null) {
            sql += " WHERE type = ?";
        }
        sql += " ORDER BY sort_order";

        PreparedStatement stmt = conn.prepareStatement(sql);

        if (type != null) {
            stmt.setString(1, type);
        }

        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            list.add(new ShowDto(
                rs.getInt("id"),
                rs.getString("title"),
                rs.getString("description"),
                rs.getString("image_url")
            ));
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    sendJson(ex, 200, showsToJson(list));
});
        server.createContext("/api/bookings", ex -> {
    cors(ex);
    if (isOptions(ex)) return;

    if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
        sendJson(ex, 405, "{\"error\":\"Method not allowed\"}");
        return;
    }

    JwtUtil.DecodedToken jwt = requireJwt(ex);
    Integer userId = getRequiredUserId(jwt, userDao);

    String body = readBody(ex);
    int eventId = jsonInt(body, "eventId");
    List<Integer> ticketIds = jsonIntArray(body, "ticketIds");
    String fullName = jsonStr(body, "fullName");
    String phone = jsonStr(body, "phone");
    String email = jsonStr(body, "email");
    String paymentMethod = jsonStr(body, "paymentMethod");

    BookingDao.BookingResult result = bookingDao.createBooking(
            userId,
            eventId,
            ticketIds,
            fullName == null ? "" : fullName.trim(),
            phone == null ? "" : phone.trim(),
            email == null ? "" : email.trim(),
            paymentMethod == null ? "onsite" : paymentMethod.trim()
    );

    if (!result.isSuccess()) {
        sendJson(ex, 400, "{\"error\":\"" + esc(result.getError()) + "\"}");
        return;
    }

    sendJson(ex, 201, "{"
            + "\"status\":\"reserved\","
            + "\"orderId\":" + result.getOrderId() + ","
            + "\"reservationCode\":\"" + esc(result.getReservationCode()) + "\""
            + "}");
});

        server.createContext("/api/bookings/my", ex -> {
    cors(ex);
    if (isOptions(ex)) return;

    if (!"GET".equalsIgnoreCase(ex.getRequestMethod())) {
        sendJson(ex, 405, "{\"error\":\"Method not allowed\"}");
        return;
    }

    JwtUtil.DecodedToken jwt = requireJwt(ex);
    Integer userId = getRequiredUserId(jwt, userDao);
    List<BookingDao.BookingRecord> bookings = bookingDao.listBookingsForUser(userId);
    sendJson(ex, 200, bookingsToJson(bookings));
});

        server.createContext("/api/seats", ex -> {
    cors(ex);
    if (isOptions(ex)) return;

    if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
        sendJson(ex, 405, "{\"error\":\"Method not allowed\"}");
        return;
    }

    try {
        String body = new String(ex.getRequestBody().readAllBytes());
        Map<String, String> data = parseJson(body);

        int showId = Integer.parseInt(data.get("showId"));
        String seatsStr = data.get("seats");

        String[] seats = seatsStr.split(",");

        try (Connection conn = Database.getConnection()) {

            for (String s : seats) {
                String[] parts = s.split("-");
                int row = Integer.parseInt(parts[0]);
                int col = Integer.parseInt(parts[1]);

                PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO seats (show_id, seat_row, seat_col) VALUES (?, ?, ?)"
                );

                stmt.setInt(1, showId);
                stmt.setInt(2, row);
                stmt.setInt(3, col);

                stmt.executeUpdate();
            }
        }

        sendJson(ex, 200, "{\"status\":\"ok\"}");

    } catch (Exception e) {
        e.printStackTrace();
        sendJson(ex, 500, "{\"error\":\"hiba\"}");
    }
});
        
        

        // ==============================
        // EVENTS - LISTÁZÁS
        // GET /api/events
        // ==============================
        server.createContext("/api/events", ex -> {
            cors(ex);
            if (isOptions(ex)) return;

            if (!"GET".equalsIgnoreCase(ex.getRequestMethod())) {
                sendJson(ex, 405, "{\"error\":\"Method not allowed\"}");
                return;
            }

            List<Event> events = eventDao.getAll();
            sendJson(ex, 200, eventsToJson(events));
        });

        // ==============================
        // MOVIES - MOZI FILMEK (ÚJ)
        // GET /api/movies
        // DB-ből: events(type='cinema') + movie_info join
        // ==============================
        server.createContext("/api/movies", ex -> {
            cors(ex);
            if (isOptions(ex)) return;

            if (!"GET".equalsIgnoreCase(ex.getRequestMethod())) {
                sendJson(ex, 405, "{\"error\":\"Method not allowed\"}");
                return;
            }

            List<MovieDto> movies = eventDao.getCinemaMovies();
            sendJson(ex, 200, moviesToJson(movies));
        });

        // ==============================
        // THEATRES (lista)
        // GET /api/theatres
        // ==============================
        server.createContext("/api/theatres", ex -> {
            cors(ex);
            if (isOptions(ex)) return;

            if (!"GET".equalsIgnoreCase(ex.getRequestMethod())) {
                sendJson(ex, 405, "{\"error\":\"Method not allowed\"}");
                return;
            }

            List<Theater> theatres = theaterDao.getAllTheatres();
            sendJson(ex, 200, theatresToJson(theatres));
        });

        // ==============================
        // TICKETS - LISTÁZÁS EVENTHEZ
        // GET /api/tickets?eventId=7
        // Authorization opcionális, hogy a frontend lássa a saját foglalásait
        // ==============================
        server.createContext("/api/tickets", ex -> {
            cors(ex);
            if (isOptions(ex)) return;

            if (!"GET".equalsIgnoreCase(ex.getRequestMethod())) {
                sendJson(ex, 405, "{\"error\":\"Method not allowed\"}");
                return;
            }

            int eventId = queryInt(ex.getRequestURI().getQuery(), "eventId", -1);
            if (eventId <= 0) {
                sendJson(ex, 400, "{\"error\":\"Missing eventId\"}");
                return;
            }

            Integer currentUserId = tryResolveUserId(ex, userDao);
            List<Ticket> tickets = ticketDao.listTicketsForEvent(eventId);
            sendJson(ex, 200, ticketsToJson(tickets, currentUserId));
        });

        server.createContext("/api/tickets/my-reservations", ex -> {
            cors(ex);
            if (isOptions(ex)) return;

            if (!"GET".equalsIgnoreCase(ex.getRequestMethod())) {
                sendJson(ex, 405, "{\"error\":\"Method not allowed\"}");
                return;
            }

            JwtUtil.DecodedToken jwt = requireJwt(ex);
            Integer userId = getRequiredUserId(jwt, userDao);
            List<Ticket> tickets = ticketDao.listActiveReservationsForUser(userId);
            sendJson(ex, 200, ticketsToJson(tickets, userId));
        });

        server.createContext("/api/tickets/reserve", ex -> {
            cors(ex);
            if (isOptions(ex)) return;

            if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
                sendJson(ex, 405, "{\"error\":\"Method not allowed\"}");
                return;
            }

            JwtUtil.DecodedToken jwt = requireJwt(ex);
            Integer userId = getRequiredUserId(jwt, userDao);

            String body = readBody(ex);
            int ticketId = jsonInt(body, "ticketId");
            if (ticketId <= 0) {
                sendJson(ex, 400, "{\"error\":\"Missing ticketId\"}");
                return;
            }

            boolean ok = ticketDao.reserveTicket(ticketId, userId);
            if (!ok) {
                sendJson(ex, 400, "{\"error\":\"Cannot reserve\"}");
                return;
            }

            Ticket ticket = ticketDao.findById(ticketId);
            String response = ticket == null
                    ? "{\"status\":\"reserved\"}"
                    : "{"
                    + "\"status\":\"reserved\","
                    + "\"ticketId\":" + ticket.getId() + ","
                    + "\"reservedUntil\":\"" + esc(String.valueOf(ticket.getReservedUntil())) + "\""
                    + "}";
            sendJson(ex, 200, response);
        });

        // ==============================
        // TICKET - BUY
        // POST /api/tickets/buy
        // Header: Authorization: Bearer <token>
        // body: {"ticketId":1}
        // ==============================
        server.createContext("/api/tickets/buy", ex -> {
            cors(ex);
            if (isOptions(ex)) return;

            if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
                sendJson(ex, 405, "{\"error\":\"Method not allowed\"}");
                return;
            }

            JwtUtil.DecodedToken jwt = requireJwt(ex);
            Integer userId = getRequiredUserId(jwt, userDao);

            String body = readBody(ex);
            int ticketId = jsonInt(body, "ticketId");
            if (ticketId <= 0) {
                sendJson(ex, 400, "{\"error\":\"Missing ticketId\"}");
                return;
            }

            TicketDao.PurchaseResult result = ticketDao.buyTicket(ticketId, userId);
            if (!result.isSuccess()) {
                sendJson(ex, 400, "{\"error\":\"" + esc(result.getError()) + "\"}");
                return;
            }

            sendJson(ex, 200, "{\"status\":\"sold\",\"orderId\":" + result.getOrderId() + "}");
        });

        // ==============================
        // TICKET - CANCEL (csak saját aktív foglalás törölhető)
        // POST /api/tickets/cancel
        // Header: Authorization: Bearer <token>
        // body: {"ticketId":1}
        // ==============================
        server.createContext("/api/tickets/cancel", ex -> {
            cors(ex);
            if (isOptions(ex)) return;

            if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
                sendJson(ex, 405, "{\"error\":\"Method not allowed\"}");
                return;
            }

            JwtUtil.DecodedToken jwt = requireJwt(ex);
            Integer userId = getRequiredUserId(jwt, userDao);

            String body = readBody(ex);
            int ticketId = jsonInt(body, "ticketId");
            if (ticketId <= 0) {
                sendJson(ex, 400, "{\"error\":\"Missing ticketId\"}");
                return;
            }

            boolean ok = ticketDao.cancelReservation(ticketId, userId);
            sendJson(ex, ok ? 200 : 400, ok ? "{\"status\":\"available\"}" : "{\"error\":\"Cannot cancel\"}");
        });
        
    // ADMIN: users list + delete
server.createContext("/api/admin/users", ex -> {
    cors(ex);
    if (isOptions(ex)) return;

    // auth + role check
    JwtUtil.DecodedToken jwt = requireJwt(ex);
    if (!"ADMIN".equalsIgnoreCase(jwt.getRole())) {
        sendJson(ex, 403, "{\"error\":\"Admin only\"}");
        return;
    }

    if ("GET".equalsIgnoreCase(ex.getRequestMethod())) {
        List<User> users = userDao.findAll();
        sendJson(ex, 200, usersToJson(users));
        return;
    }

    if ("DELETE".equalsIgnoreCase(ex.getRequestMethod())) {
        int id = queryInt(ex.getRequestURI().getQuery(), "id", -1);
        if (id <= 0) { sendJson(ex, 400, "{\"error\":\"Missing id\"}"); return; }

        boolean ok = userDao.deleteById(id);
        sendJson(ex, ok ? 200 : 404, ok ? "{\"status\":\"deleted\"}" : "{\"error\":\"Not found\"}");
        return;
    }

    sendJson(ex, 405, "{\"error\":\"Method not allowed\"}");
});
    
     // ADMIN: events CRUD
server.createContext("/api/admin/events", ex -> {
    cors(ex);
    if (isOptions(ex)) return;

    JwtUtil.DecodedToken jwt = requireJwt(ex);
    if (!"ADMIN".equalsIgnoreCase(jwt.getRole())) {
        sendJson(ex, 403, "{\"error\":\"Admin only\"}");
        return;
    }

    if ("GET".equalsIgnoreCase(ex.getRequestMethod())) {
        String type = null;
        String q = ex.getRequestURI().getQuery();
        if (q != null && q.contains("type=")) {
            for (String part : q.split("&")) {
                String[] kv = part.split("=");
                if (kv.length == 2 && kv[0].equals("type")) type = kv[1];
            }
        }
        if (type == null) type = "cinema";
        List<Event> list = eventDao.getByType(type);
        sendJson(ex, 200, eventsToJson(list));
        return;
    }

    if ("POST".equalsIgnoreCase(ex.getRequestMethod())) {
        String body = readBody(ex);
        String title = jsonStr(body, "title");
        String type = jsonStr(body, "type");
        int room = jsonInt(body, "room");
        int seats = jsonInt(body, "seats");
        String start = jsonStr(body, "start");
        String end = jsonStr(body, "end");

        if (title == null || type == null || start == null || end == null || room <= 0 || seats <= 0) {
            sendJson(ex, 400, "{\"error\":\"Missing fields\"}");
            return;
        }

        boolean ok = eventDao.insertEvent(title.trim(), type.trim(), room, seats, start.trim(), end.trim());
        sendJson(ex, ok ? 201 : 400, ok ? "{\"status\":\"created\"}" : "{\"error\":\"Cannot create\"}");
        return;
    }

    if ("DELETE".equalsIgnoreCase(ex.getRequestMethod())) {
        int id = queryInt(ex.getRequestURI().getQuery(), "id", -1);
        if (id <= 0) { sendJson(ex, 400, "{\"error\":\"Missing id\"}"); return; }

        boolean ok = eventDao.deleteById(id);
        sendJson(ex, ok ? 200 : 404, ok ? "{\"status\":\"deleted\"}" : "{\"error\":\"Not found\"}");
        return;
    }

    sendJson(ex, 405, "{\"error\":\"Method not allowed\"}");
});
    

        server.start();
        System.out.println("REST API fut: http://localhost:9090");
        System.out.println("GET /api/events");
        System.out.println("GET /api/movies");
        System.out.println("GET /api/tickets?eventId=7");
        System.out.println("POST /api/auth/login");
        System.out.println("POST /api/tickets/reserve (Bearer)");
        System.out.println("POST /api/tickets/buy (Bearer)");
        System.out.println("POST /api/tickets/cancel (Bearer)");
        System.out.println("DELETE /api/admin/users?id=2 (Bearer ADMIN)");
    }

    // ==============================
    // HELPERS
    // ==============================

       
    
    private static boolean isOptions(HttpExchange ex) throws IOException {
        if ("OPTIONS".equalsIgnoreCase(ex.getRequestMethod())) {
            ex.sendResponseHeaders(204, -1);
            return true;
        }
        return false;
    }

    private static void cors(HttpExchange ex) {
        Headers h = ex.getResponseHeaders();
        h.set("Access-Control-Allow-Origin", "*");
        h.set("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS");
        h.set("Access-Control-Allow-Headers", "Content-Type,Authorization");
    }

    private static String bearer(Headers headers) {
        String a = headers.getFirst("Authorization");
        if (a == null) return null;
        if (!a.startsWith("Bearer ")) return null;
        return a.substring("Bearer ".length()).trim();
    }


    private static String readBody(HttpExchange ex) throws IOException {
        try (InputStream in = ex.getRequestBody()) {
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    private static void sendJson(HttpExchange ex, int code, String json) throws IOException {
        byte[] data = json.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        ex.sendResponseHeaders(code, data.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(data);
        }
    }

    private static String jsonStr(String json, String key) {
        if (json == null) return null;

        java.util.regex.Pattern p = java.util.regex.Pattern.compile(
                "\\\"" + java.util.regex.Pattern.quote(key) + "\\\"\\s*:\\s*\\\"([^\\\"]*)\\\""
        );
        java.util.regex.Matcher m = p.matcher(json);
        if (m.find()) return m.group(1);
        return null;
    }

    private static int jsonInt(String json, String key) {
        if (json == null) return 0;
        String p = "\"" + key + "\":";
        int i = json.indexOf(p);
        if (i < 0) return 0;
        i += p.length();
        while (i < json.length() && Character.isWhitespace(json.charAt(i))) i++;
        int e = i;
        while (e < json.length() && (Character.isDigit(json.charAt(e)) || json.charAt(e) == '-')) e++;
        return Integer.parseInt(json.substring(i, e));
    }

    private static List<Integer> jsonIntArray(String json, String key) {
        List<Integer> list = new ArrayList<>();
        if (json == null) return list;

        String marker = "\"" + key + "\":";
        int keyIndex = json.indexOf(marker);
        if (keyIndex < 0) return list;

        int arrayStart = json.indexOf('[', keyIndex + marker.length());
        if (arrayStart < 0) return list;
        int arrayEnd = json.indexOf(']', arrayStart + 1);
        if (arrayEnd < 0) return list;

        String content = json.substring(arrayStart + 1, arrayEnd).trim();
        if (content.isEmpty()) return list;

        for (String part : content.split(",")) {
            String trimmed = part.trim();
            if (trimmed.isEmpty()) continue;
            list.add(Integer.parseInt(trimmed));
        }
        return list;
    }

    private static int queryInt(String query, String key, int def) {
        if (query == null) return def;
        for (String part : query.split("&")) {
            String[] kv = part.split("=");
            if (kv.length == 2 && kv[0].equals(key)) {
                try {
                    return Integer.parseInt(kv[1]);
                } catch (Exception ignored) {
                }
            }
        }
        return def;
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static String eventsToJson(List<Event> list) {
        StringBuilder sb = new StringBuilder("[");
        boolean first = true;
        for (Event e : list) {
            if (!first) sb.append(",");
            first = false;
            sb.append("{")
                    .append("\"id\":").append(e.getId()).append(",")
                    .append("\"title\":\"").append(esc(e.getTitle())).append("\",")
                    .append("\"room\":\"").append(esc(e.getRoom())).append("\",")
                    .append("\"type\":\"").append(esc(e.getType())).append("\",")
                    .append("\"start\":\"").append(esc(String.valueOf(e.getStart()))).append("\",")
                    .append("\"end\":\"").append(esc(String.valueOf(e.getEnd()))).append("\",")
                    .append("\"seats\":").append(e.getSeats())
                    .append("}");
        }
        sb.append("]");
        return sb.toString();
    }

    private static String moviesToJson(List<MovieDto> list) {
        StringBuilder sb = new StringBuilder("[");
        boolean first = true;
        for (MovieDto m : list) {
            if (!first) sb.append(",");
            first = false;
            sb.append("{")
                    .append("\"id\":").append(m.getId()).append(",")
                    .append("\"title\":\"").append(esc(m.getTitle())).append("\",")
                    .append("\"genre\":\"").append(esc(m.getGenre())).append("\",")
                    .append("\"writer\":\"").append(esc(m.getWriter())).append("\",")
                    .append("\"lengthMin\":").append(m.getLengthMin()).append(",")
                    .append("\"start\":\"").append(esc(m.getStart())).append("\",")
                    .append("\"end\":\"").append(esc(m.getEnd())).append("\",")
                    .append("\"room\":\"").append(esc(m.getRoom())).append("\"")
                    .append("}");
        }
        sb.append("]");
        return sb.toString();
    }

    private static String ticketsToJson(List<Ticket> list, Integer currentUserId) {
        StringBuilder sb = new StringBuilder("[");
        boolean first = true;
        for (Ticket t : list) {
            if (!first) sb.append(",");
            first = false;

            boolean reservedByCurrentUser = currentUserId != null
                    && t.getReservedByUserId() != null
                    && currentUserId.intValue() == t.getReservedByUserId().intValue();

            sb.append("{")
                    .append("\"id\":").append(t.getId()).append(",")
                    .append("\"eventId\":").append(t.getEventId()).append(",")
                    .append("\"seatLabel\":\"").append(esc(t.getSeatLabel())).append("\",")
                    .append("\"price\":").append(t.getPrice()).append(",")
                    .append("\"status\":\"").append(esc(t.getNormalizedStatus())).append("\",")
                    .append("\"created\":\"").append(esc(String.valueOf(t.getCreated()))).append("\",")
                    .append("\"reservedByCurrentUser\":").append(reservedByCurrentUser);

            if (t.getReservedUntil() != null) {
                sb.append(",\"reservedUntil\":\"").append(esc(String.valueOf(t.getReservedUntil()))).append("\"");
            }

            sb.append("}");
        }
        sb.append("]");
        return sb.toString();
    }

    private static String theatresToJson(List<Theater> list) {
        StringBuilder sb = new StringBuilder("[");
        boolean first = true;
        for (Theater t : list) {
            if (!first) sb.append(",");
            first = false;
            sb.append("{")
                    .append("\"id\":").append(t.getId()).append(",")
                    .append("\"name\":\"").append(esc(t.getName())).append("\",")
                    .append("\"city\":\"").append(esc(t.getCity())).append("\",")
                    .append("\"address\":\"").append(esc(t.getAddress())).append("\",")
                    .append("\"phone\":\"").append(esc(t.getPhone())).append("\",")
                    .append("\"website\":\"").append(esc(t.getWebsite())).append("\"")
                    .append("}");
        }
        sb.append("]");
        return sb.toString();
    }
    
    private static JwtUtil.DecodedToken requireJwt(HttpExchange ex) throws IOException {
    String token = bearer(ex.getRequestHeaders());
    if (token == null) {
        sendJson(ex, 401, "{\"error\":\"Missing token\"}");
        throw new RuntimeException("missing token");
    }
    try {
        return JwtUtil.verifyToken(token);
    } catch (Exception e) {
        sendJson(ex, 401, "{\"error\":\"Invalid token\"}");
        throw new RuntimeException("invalid token");
    }
}

private static Integer tryResolveUserId(HttpExchange ex, UserDao userDao) {
    String token = bearer(ex.getRequestHeaders());
    if (token == null || token.isBlank()) {
        return null;
    }
    try {
        JwtUtil.DecodedToken jwt = JwtUtil.verifyToken(token);
        return getRequiredUserId(jwt, userDao);
    } catch (Exception ignored) {
        return null;
    }
}

private static Integer getRequiredUserId(JwtUtil.DecodedToken jwt, UserDao userDao) {
    if (jwt == null || jwt.getEmail() == null || jwt.getEmail().isBlank()) {
        throw new RuntimeException("missing user in token");
    }

    User user = userDao.findByEmail(jwt.getEmail());
    if (user == null) {
        throw new RuntimeException("user not found for token");
    }
    return user.getId();
}

private static String usersToJson(List<User> list) {
    StringBuilder sb = new StringBuilder("[");
    boolean first = true;
    for (User u : list) {
        if (!first) sb.append(",");
        first = false;
        sb.append("{")
          .append("\"id\":").append(u.getId()).append(",")
          .append("\"name\":\"").append(esc(u.getName())).append("\",")
          .append("\"email\":\"").append(esc(u.getEmail())).append("\",")
          .append("\"role\":\"").append(u.getRole().name()).append("\"")
          .append("}");
    }
    sb.append("]");
    return sb.toString();
    
}
private static String profileToJson(User user) {
    if (user == null) return "{}";
    return "{"
            + "\"fullName\":\"" + esc(user.getName()) + "\","
            + "\"userName\":\"" + esc(user.getUsername()) + "\","
            + "\"phone\":\"" + esc(user.getPhone()) + "\","
            + "\"email\":\"" + esc(user.getEmail()) + "\""
            + "}";
}

private static String bookingsToJson(List<BookingDao.BookingRecord> list) {
    StringBuilder sb = new StringBuilder("[");
    boolean first = true;
    for (BookingDao.BookingRecord b : list) {
        if (!first) sb.append(",");
        first = false;
        sb.append("{")
          .append("\"orderId\":").append(b.getOrderId()).append(",")
          .append("\"reservationCode\":\"").append(esc(b.getReservationCode())).append("\",")
          .append("\"eventTitle\":\"").append(esc(b.getEventTitle())).append("\",")
          .append("\"room\":\"").append(esc(b.getRoom())).append("\",")
          .append("\"seats\":\"").append(esc(b.getSeats())).append("\",")
          .append("\"total\":").append(b.getTotal()).append(",")
          .append("\"status\":\"").append(esc(b.getStatus())).append("\",")
          .append("\"paymentMethod\":\"").append(esc(b.getPaymentMethod())).append("\",")
          .append("\"customerName\":\"").append(esc(b.getCustomerName())).append("\",")
          .append("\"customerPhone\":\"").append(esc(b.getCustomerPhone())).append("\",")
          .append("\"customerEmail\":\"").append(esc(b.getCustomerEmail())).append("\",")
          .append("\"created\":\"").append(esc(String.valueOf(b.getCreated()))).append("\",")
          .append("\"eventStart\":\"").append(esc(String.valueOf(b.getEventStart()))).append("\"")
          .append("}");
    }
    sb.append("]");
    return sb.toString();
}

private static String weeklyToJson(List<Map<String, Object>> list) {
    StringBuilder sb = new StringBuilder("[");
    boolean first = true;

    for (Map<String, Object> item : list) {
        if (!first) sb.append(",");
        first = false;

        sb.append("{")
          .append("\"title\":\"").append(item.get("title")).append("\",")
          .append("\"image_url\":\"").append(item.get("image_url")).append("\"")
          .append("}");
    }

    sb.append("]");
    return sb.toString();
}

private static String showsToJson(List<ShowDto> list) {
    StringBuilder sb = new StringBuilder("[");
    boolean first = true;

    for (ShowDto s : list) {
        if (!first) sb.append(",");
        first = false;

        sb.append("{")
          .append("\"id\":").append(s.getId()).append(",")
          .append("\"title\":\"").append(esc(s.getTitle())).append("\",")
          .append("\"description\":\"").append(esc(s.getDescription())).append("\",")
          .append("\"image_url\":\"").append(esc(s.getImageUrl())).append("\"")
          .append("}");
    }

    sb.append("]");
    return sb.toString();
}
private static Map<String, String> parseJson(String json) {
    Map<String, String> map = new HashMap<>();

    json = json.trim();
    json = json.substring(1, json.length() - 1);

    String[] pairs = json.split(",");

    for (String pair : pairs) {
        String[] kv = pair.split(":");

        if (kv.length == 2) {
            String key = kv[0].trim().replace("\"", "");
            String value = kv[1].trim().replace("\"", "");

            map.put(key, value);
        }
    }

    return map;
}


}

