/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;



public class MovieDto {
    private int id;
    private String title;
    private String genre;
    private String writer;
    private int lengthMin;
    private String start;
    private String end;
    private String room;

    public MovieDto(int id, String title, String genre, String writer, int lengthMin,
                    String start, String end, String room) {
        this.id = id;
        this.title = title;
        this.genre = genre;
        this.writer = writer;
        this.lengthMin = lengthMin;
        this.start = start;
        this.end = end;
        this.room = room;
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getGenre() { return genre; }
    public String getWriter() { return writer; }
    public int getLengthMin() { return lengthMin; }
    public String getStart() { return start; }
    public String getEnd() { return end; }
    public String getRoom() { return room; }
}
