package model;

public class User {
    private int id;
    private String name;
    private String email;
    private String password;
    private Role role;
    private String username;
    private String phone;

    public User(int id, String email, String password, String name, Role role) {
        this(id, email, password, name, role, null, null);
    }

    public User(int id, String email, String password, String name, Role role, String username, String phone) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
        this.username = username;
        this.phone = phone;
    }

    public User(int id, String name, String email) {
        this(id, email, "", name, Role.USER, null, null);
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPassword() { return password; }
    public Role getRole() { return role; }
    public String getUsername() { return username; }
    public String getPhone() { return phone; }
}
