package model;

import java.sql.Timestamp;

public class Ticket {
    private int id;
    private int eventId;
    private String seatLabel;
    private double price;
    private String status;
    private Timestamp created;
    private Integer reservedByUserId;
    private Timestamp reservedUntil;

    public Ticket(int id, int eventId, String seatLabel, double price, String status, Timestamp created) {
        this(id, eventId, seatLabel, price, status, created, null, null);
    }

    public Ticket(int id, int eventId, String seatLabel, double price, String status, Timestamp created,
                  Integer reservedByUserId, Timestamp reservedUntil) {
        this.id = id;
        this.eventId = eventId;
        this.seatLabel = seatLabel;
        this.price = price;
        this.status = status;
        this.created = created;
        this.reservedByUserId = reservedByUserId;
        this.reservedUntil = reservedUntil;
    }

    public int getId() { return id; }
    public int getEventId() { return eventId; }
    public String getSeatLabel() { return seatLabel; }
    public double getPrice() { return price; }
    public String getStatus() { return status; }
    public Timestamp getCreated() { return created; }
    public Integer getReservedByUserId() { return reservedByUserId; }
    public Timestamp getReservedUntil() { return reservedUntil; }

    public String getNormalizedStatus() {
        if (status == null || status.isBlank()) {
            return "available";
        }
        if ("paid".equalsIgnoreCase(status)) {
            return "sold";
        }
        return status.toLowerCase();
    }
}
