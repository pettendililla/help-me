package dao;

import model.Role;
import model.User;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDao {

    private Boolean profileColumnsAvailableCache = null;

    public User findByEmail(String email) {
        try (Connection conn = Database.getConnection()) {
            String sql = hasProfileColumns(conn)
                    ? "SELECT id, email, password, name, role, username, phone FROM users WHERE email = ?"
                    : "SELECT id, email, password, name, role, NULL AS username, NULL AS phone FROM users WHERE email = ?";

            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, email);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return mapUser(rs);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    public User findById(int id) {
        try (Connection conn = Database.getConnection()) {
            String sql = hasProfileColumns(conn)
                    ? "SELECT id, email, password, name, role, username, phone FROM users WHERE id = ?"
                    : "SELECT id, email, password, name, role, NULL AS username, NULL AS phone FROM users WHERE id = ?";

            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return mapUser(rs);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean updateProfile(int userId, String fullName, String username, String phone, String email) {
        try (Connection conn = Database.getConnection()) {
            boolean hasProfileColumns = hasProfileColumns(conn);
            String sql = hasProfileColumns
                    ? "UPDATE users SET name = ?, username = ?, phone = ?, email = ? WHERE id = ?"
                    : "UPDATE users SET name = ?, email = ? WHERE id = ?";

            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                if (hasProfileColumns) {
                    ps.setString(1, fullName);
                    ps.setString(2, username);
                    ps.setString(3, phone);
                    ps.setString(4, email);
                    ps.setInt(5, userId);
                } else {
                    ps.setString(1, fullName);
                    ps.setString(2, email);
                    ps.setInt(3, userId);
                }
                return ps.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteById(int id) {
        String sql = "DELETE FROM users WHERE id = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public int countAdmins() {
    String sql = "SELECT COUNT(*) FROM users WHERE role = 'admin'";
    try (Connection conn = Database.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        if (rs.next()) return rs.getInt(1);

    } catch (SQLException e) {
        e.printStackTrace();
    }
    return 0;
}

public boolean createUser(String email, String password, String name, String role) {
    String sql = "INSERT INTO users (email, password, name, role) VALUES (?, ?, ?, ?)";

    try (Connection conn = Database.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setString(1, email);
        ps.setString(2, password);
        ps.setString(3, name);
        ps.setString(4, role);
        return ps.executeUpdate() > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}

    private User mapUser(ResultSet rs) throws SQLException {
        int id = rs.getInt("id");
        String email = rs.getString("email");
        String password = rs.getString("password");
        String name = rs.getString("name");
        String roleStr = rs.getString("role");
        String username = rs.getString("username");
        String phone = rs.getString("phone");
        Role role = Role.valueOf(roleStr.toUpperCase());

        return new User(id, email, password, name, role, username, phone);
    }
    
public List<User> findAll() {
    List<User> list = new ArrayList<>();
    try (Connection conn = Database.getConnection()) {
        String sql = hasProfileColumns(conn)
                ? "SELECT id, email, password, name, role, username, phone FROM users ORDER BY id"
                : "SELECT id, email, password, name, role, NULL AS username, NULL AS phone FROM users ORDER BY id";

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapUser(rs));
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return list;
}

    public List<User> getAllUsers() {
    List<User> list = new java.util.ArrayList<>();
    try (Connection conn = Database.getConnection()) {
        String sql = hasProfileColumns(conn)
                ? "SELECT id, email, password, name, role, username, phone FROM users ORDER BY role, id"
                : "SELECT id, email, password, name, role, NULL AS username, NULL AS phone FROM users ORDER BY role, id";

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapUser(rs));
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return list;
}

    private boolean hasProfileColumns(Connection conn) throws SQLException {
        if (profileColumnsAvailableCache != null) {
            return profileColumnsAvailableCache;
        }
        DatabaseMetaData meta = conn.getMetaData();
        boolean hasUsername = hasColumn(meta, conn.getCatalog(), "users", "username");
        boolean hasPhone = hasColumn(meta, conn.getCatalog(), "users", "phone");
        profileColumnsAvailableCache = hasUsername && hasPhone;
        return profileColumnsAvailableCache;
    }

    private boolean hasColumn(DatabaseMetaData metaData, String catalog, String tableName, String columnName) throws SQLException {
        try (ResultSet rs = metaData.getColumns(catalog, null, tableName, columnName)) {
            if (rs.next()) {
                return true;
            }
        }
        try (ResultSet rs = metaData.getColumns(catalog, null, tableName.toUpperCase(), columnName.toUpperCase())) {
            return rs.next();
        }
    }
}
