package dao;

import model.Ticket;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class BookingDao {

    private static final int RESERVATION_MINUTES = 15;
    private Boolean reservationColumnsAvailableCache = null;
    private Boolean orderExtraColumnsAvailableCache = null;

    public static class BookingResult {
        private final boolean success;
        private final Integer orderId;
        private final String reservationCode;
        private final String error;

        public BookingResult(boolean success, Integer orderId, String reservationCode, String error) {
            this.success = success;
            this.orderId = orderId;
            this.reservationCode = reservationCode;
            this.error = error;
        }

        public boolean isSuccess() { return success; }
        public Integer getOrderId() { return orderId; }
        public String getReservationCode() { return reservationCode; }
        public String getError() { return error; }
    }

    public static class BookingRecord {
        private final int orderId;
        private final String reservationCode;
        private final String eventTitle;
        private final Timestamp eventStart;
        private final String room;
        private final String seats;
        private final double total;
        private final String status;
        private final String paymentMethod;
        private final String customerName;
        private final String customerPhone;
        private final String customerEmail;
        private final Timestamp created;

        public BookingRecord(int orderId, String reservationCode, String eventTitle, Timestamp eventStart,
                             String room, String seats, double total, String status, String paymentMethod,
                             String customerName, String customerPhone, String customerEmail, Timestamp created) {
            this.orderId = orderId;
            this.reservationCode = reservationCode;
            this.eventTitle = eventTitle;
            this.eventStart = eventStart;
            this.room = room;
            this.seats = seats;
            this.total = total;
            this.status = status;
            this.paymentMethod = paymentMethod;
            this.customerName = customerName;
            this.customerPhone = customerPhone;
            this.customerEmail = customerEmail;
            this.created = created;
        }

        public int getOrderId() { return orderId; }
        public String getReservationCode() { return reservationCode; }
        public String getEventTitle() { return eventTitle; }
        public Timestamp getEventStart() { return eventStart; }
        public String getRoom() { return room; }
        public String getSeats() { return seats; }
        public double getTotal() { return total; }
        public String getStatus() { return status; }
        public String getPaymentMethod() { return paymentMethod; }
        public String getCustomerName() { return customerName; }
        public String getCustomerPhone() { return customerPhone; }
        public String getCustomerEmail() { return customerEmail; }
        public Timestamp getCreated() { return created; }
    }

    public BookingResult createBooking(int userId, int eventId, List<Integer> ticketIds,
                                       String fullName, String phone, String email, String paymentMethod) {
        if (userId <= 0) {
            return new BookingResult(false, null, null, "Hiányzó felhasználó.");
        }
        if (eventId <= 0) {
            return new BookingResult(false, null, null, "Hiányzó esemény.");
        }
        if (ticketIds == null || ticketIds.isEmpty()) {
            return new BookingResult(false, null, null, "Nincs kiválasztott hely.");
        }
        if (fullName == null || fullName.isBlank() || email == null || email.isBlank()) {
            return new BookingResult(false, null, null, "Hiányzó személyes adatok.");
        }

        Set<Integer> uniqueIds = new HashSet<>(ticketIds);
        if (uniqueIds.size() != ticketIds.size()) {
            return new BookingResult(false, null, null, "Dupla helyválasztás nem megengedett.");
        }

        String normalizedPayment = (paymentMethod == null || paymentMethod.isBlank()) ? "onsite" : paymentMethod.trim().toLowerCase();
        if (!normalizedPayment.equals("onsite") && !normalizedPayment.equals("cash")) {
            normalizedPayment = "onsite";
        }

        try (Connection conn = Database.getConnection()) {
            conn.setAutoCommit(false);
            try {
                boolean hasReservationColumns = hasReservationColumns(conn);
                boolean hasOrderExtraColumns = hasOrderExtraColumns(conn);

                releaseExpiredReservations(conn, hasReservationColumns);

                List<Ticket> tickets = findTicketsForUpdate(conn, new ArrayList<>(uniqueIds), hasReservationColumns);
                if (tickets.size() != uniqueIds.size()) {
                    conn.rollback();
                    return new BookingResult(false, null, null, "Néhány kiválasztott hely nem található.");
                }

                double total = 0.0;
                String orderTitle = null;
                for (Ticket ticket : tickets) {
                    if (ticket.getEventId() != eventId) {
                        conn.rollback();
                        return new BookingResult(false, null, null, "A kiválasztott helyek nem ugyanahhoz az előadáshoz tartoznak.");
                    }

                    String normalizedStatus = ticket.getNormalizedStatus();
                    boolean canReserve = "available".equals(normalizedStatus)
                            || ("reserved".equals(normalizedStatus)
                            && ticket.getReservedByUserId() != null
                            && ticket.getReservedByUserId() == userId);

                    if (!canReserve) {
                        conn.rollback();
                        return new BookingResult(false, null, null, "Van köztük már foglalt vagy elkelt hely.");
                    }

                    total += ticket.getPrice();
                }

                orderTitle = findEventTitle(conn, eventId);
                if (orderTitle == null || orderTitle.isBlank()) {
                    orderTitle = "Foglalás";
                }

                reserveTickets(conn, new ArrayList<>(uniqueIds), userId, hasReservationColumns);
                String reservationCode = generateReservationCode(conn, hasOrderExtraColumns);
                int orderId = insertOrder(conn, userId, total, orderTitle, fullName, phone, email, normalizedPayment, reservationCode, hasOrderExtraColumns);
                insertBoughtTickets(conn, orderId, tickets);

                conn.commit();
                return new BookingResult(true, orderId, reservationCode, null);
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
                return new BookingResult(false, null, null, "Adatbázis hiba.");
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return new BookingResult(false, null, null, "Kapcsolódási hiba.");
        }
    }

    public List<BookingRecord> listBookingsForUser(int userId) {
        List<BookingRecord> list = new ArrayList<>();
        if (userId <= 0) {
            return list;
        }

        try (Connection conn = Database.getConnection()) {
            boolean hasOrderExtraColumns = hasOrderExtraColumns(conn);
            boolean hasReservationColumns = hasReservationColumns(conn);
            releaseExpiredReservations(conn, hasReservationColumns);

            String sql = hasOrderExtraColumns
                    ? "SELECT o.id AS order_id, o.reservation_code, o.total, o.status, o.payment_method, "
                    + "o.customer_name, o.customer_phone, o.customer_email, o.created, "
                    + "e.title AS event_title, e.start AS event_start, e.room AS room, "
                    + "GROUP_CONCAT(t.seat_label ORDER BY t.seat_label SEPARATOR ', ') AS seats "
                    + "FROM orders o "
                    + "LEFT JOIN bought_tickets bt ON bt.order_id = o.id "
                    + "LEFT JOIN tickets t ON t.id = bt.ticket_id "
                    + "LEFT JOIN events e ON e.id = t.event_id "
                    + "WHERE o.user_id = ? "
                    + "GROUP BY o.id, o.reservation_code, o.total, o.status, o.payment_method, o.customer_name, o.customer_phone, o.customer_email, o.created, e.title, e.start, e.room "
                    + "ORDER BY o.created DESC"
                    : "SELECT o.id AS order_id, NULL AS reservation_code, o.total, o.status, NULL AS payment_method, "
                    + "NULL AS customer_name, NULL AS customer_phone, NULL AS customer_email, o.created, "
                    + "e.title AS event_title, e.start AS event_start, e.room AS room, "
                    + "GROUP_CONCAT(t.seat_label ORDER BY t.seat_label SEPARATOR ', ') AS seats "
                    + "FROM orders o "
                    + "LEFT JOIN bought_tickets bt ON bt.order_id = o.id "
                    + "LEFT JOIN tickets t ON t.id = bt.ticket_id "
                    + "LEFT JOIN events e ON e.id = t.event_id "
                    + "WHERE o.user_id = ? "
                    + "GROUP BY o.id, o.total, o.status, o.created, e.title, e.start, e.room "
                    + "ORDER BY o.created DESC";

            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        String reservationCode = rs.getString("reservation_code");
                        if (reservationCode == null || reservationCode.isBlank()) {
                            reservationCode = String.valueOf(rs.getInt("order_id"));
                        }

                        list.add(new BookingRecord(
                                rs.getInt("order_id"),
                                reservationCode,
                                rs.getString("event_title"),
                                rs.getTimestamp("event_start"),
                                rs.getString("room"),
                                rs.getString("seats"),
                                rs.getDouble("total"),
                                normalizeStatus(rs.getString("status")),
                                rs.getString("payment_method"),
                                rs.getString("customer_name"),
                                rs.getString("customer_phone"),
                                rs.getString("customer_email"),
                                rs.getTimestamp("created")
                        ));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    private void reserveTickets(Connection conn, List<Integer> ticketIds, int userId, boolean hasReservationColumns) throws SQLException {
        String placeholders = placeholders(ticketIds.size());
        String sql = hasReservationColumns
                ? "UPDATE tickets SET status = 'reserved', reserved_by_user_id = ?, reserved_until = DATE_ADD(NOW(), INTERVAL ? MINUTE) WHERE id IN (" + placeholders + ")"
                : "UPDATE tickets SET status = 'reserved' WHERE id IN (" + placeholders + ")";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            int idx = 1;
            if (hasReservationColumns) {
                ps.setInt(idx++, userId);
                ps.setInt(idx++, RESERVATION_MINUTES);
            }
            for (Integer ticketId : ticketIds) {
                ps.setInt(idx++, ticketId);
            }
            ps.executeUpdate();
        }
    }

    private int insertOrder(Connection conn, int userId, double total, String title,
                            String fullName, String phone, String email,
                            String paymentMethod, String reservationCode,
                            boolean hasOrderExtraColumns) throws SQLException {
        String sql = hasOrderExtraColumns
                ? "INSERT INTO orders (user_id, total, status, title, customer_name, customer_phone, customer_email, payment_method, reservation_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
                : "INSERT INTO orders (user_id, total, status, title) VALUES (?, ?, ?, ?)";

        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            int idx = 1;
            ps.setInt(idx++, userId);
            ps.setDouble(idx++, total);
            ps.setString(idx++, "reserved");
            ps.setString(idx++, title);
            if (hasOrderExtraColumns) {
                ps.setString(idx++, fullName);
                ps.setString(idx++, phone);
                ps.setString(idx++, email);
                ps.setString(idx++, paymentMethod);
                ps.setString(idx++, reservationCode);
            }
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    return keys.getInt(1);
                }
            }
        }
        throw new SQLException("Foglalás létrehozása sikertelen.");
    }

    private void insertBoughtTickets(Connection conn, int orderId, List<Ticket> tickets) throws SQLException {
        String sql = "INSERT INTO bought_tickets (order_id, ticket_id, price) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            for (Ticket ticket : tickets) {
                ps.setInt(1, orderId);
                ps.setInt(2, ticket.getId());
                ps.setDouble(3, ticket.getPrice());
                ps.addBatch();
            }
            ps.executeBatch();
        }
    }

    private List<Ticket> findTicketsForUpdate(Connection conn, List<Integer> ticketIds, boolean hasReservationColumns) throws SQLException {
        List<Ticket> list = new ArrayList<>();
        String sql = hasReservationColumns
                ? "SELECT id, event_id, seat_label, price, status, created, reserved_by_user_id, reserved_until FROM tickets WHERE id IN (" + placeholders(ticketIds.size()) + ") FOR UPDATE"
                : "SELECT id, event_id, seat_label, price, status, created FROM tickets WHERE id IN (" + placeholders(ticketIds.size()) + ") FOR UPDATE";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            int idx = 1;
            for (Integer ticketId : ticketIds) {
                ps.setInt(idx++, ticketId);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Integer reservedByUserId = null;
                    Timestamp reservedUntil = null;
                    if (hasReservationColumns) {
                        Object reservedByValue = rs.getObject("reserved_by_user_id");
                        if (reservedByValue != null) {
                            reservedByUserId = ((Number) reservedByValue).intValue();
                        }
                        reservedUntil = rs.getTimestamp("reserved_until");
                    }
                    list.add(new Ticket(
                            rs.getInt("id"),
                            rs.getInt("event_id"),
                            rs.getString("seat_label"),
                            rs.getDouble("price"),
                            normalizeStatus(rs.getString("status")),
                            rs.getTimestamp("created"),
                            reservedByUserId,
                            reservedUntil
                    ));
                }
            }
        }
        return list;
    }

    private String findEventTitle(Connection conn, int eventId) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("SELECT title FROM events WHERE id = ?")) {
            ps.setInt(1, eventId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString(1);
                }
            }
        }
        return null;
    }

    private void releaseExpiredReservations(Connection conn, boolean hasReservationColumns) throws SQLException {
        if (!hasReservationColumns) {
            return;
        }
        try (PreparedStatement ps = conn.prepareStatement(
                "UPDATE tickets SET status = 'available', reserved_by_user_id = NULL, reserved_until = NULL WHERE LOWER(status) = 'reserved' AND reserved_until IS NOT NULL AND reserved_until < NOW()")) {
            ps.executeUpdate();
        }
    }

    private String generateReservationCode(Connection conn, boolean hasOrderExtraColumns) throws SQLException {
        if (!hasOrderExtraColumns) {
            return DateTimeFormatter.ofPattern("yyyyMMddHHmmss").format(LocalDateTime.now());
        }
        for (int attempt = 0; attempt < 10; attempt++) {
            String code = String.valueOf(System.currentTimeMillis()).substring(3);
            if (!reservationCodeExists(conn, code)) {
                return code;
            }
            try {
                Thread.sleep(2L);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
        }
        return DateTimeFormatter.ofPattern("yyyyMMddHHmmss").format(LocalDateTime.now());
    }

    private boolean reservationCodeExists(Connection conn, String code) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM orders WHERE reservation_code = ?")) {
            ps.setString(1, code);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

    private boolean hasReservationColumns(Connection conn) throws SQLException {
        if (reservationColumnsAvailableCache != null) {
            return reservationColumnsAvailableCache;
        }

        DatabaseMetaData metaData = conn.getMetaData();
        boolean hasReservedBy = hasColumn(metaData, conn.getCatalog(), "tickets", "reserved_by_user_id");
        boolean hasReservedUntil = hasColumn(metaData, conn.getCatalog(), "tickets", "reserved_until");
        reservationColumnsAvailableCache = hasReservedBy && hasReservedUntil;
        return reservationColumnsAvailableCache;
    }

    private boolean hasOrderExtraColumns(Connection conn) throws SQLException {
        if (orderExtraColumnsAvailableCache != null) {
            return orderExtraColumnsAvailableCache;
        }

        DatabaseMetaData metaData = conn.getMetaData();
        boolean hasName = hasColumn(metaData, conn.getCatalog(), "orders", "customer_name");
        boolean hasPhone = hasColumn(metaData, conn.getCatalog(), "orders", "customer_phone");
        boolean hasEmail = hasColumn(metaData, conn.getCatalog(), "orders", "customer_email");
        boolean hasPayment = hasColumn(metaData, conn.getCatalog(), "orders", "payment_method");
        boolean hasReservationCode = hasColumn(metaData, conn.getCatalog(), "orders", "reservation_code");
        orderExtraColumnsAvailableCache = hasName && hasPhone && hasEmail && hasPayment && hasReservationCode;
        return orderExtraColumnsAvailableCache;
    }

    private boolean hasColumn(DatabaseMetaData metaData, String catalog, String tableName, String columnName) throws SQLException {
        try (ResultSet rs = metaData.getColumns(catalog, null, tableName, columnName)) {
            if (rs.next()) {
                return true;
            }
        }
        try (ResultSet rs = metaData.getColumns(catalog, null, tableName.toUpperCase(), columnName.toUpperCase())) {
            return rs.next();
        }
    }

    private String placeholders(int count) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) {
            if (i > 0) sb.append(',');
            sb.append('?');
        }
        return sb.toString();
    }

    private String normalizeStatus(String status) {
        if (status == null || status.isBlank()) {
            return "available";
        }
        if ("paid".equalsIgnoreCase(status)) {
            return "sold";
        }
        return status.toLowerCase();
    }
}
