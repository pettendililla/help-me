package dao;

import model.Ticket;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class TicketDao {

    private static final int RESERVATION_MINUTES = 15;
    private Boolean reservationColumnsAvailableCache = null;

    public static class PurchaseResult {
        private final boolean success;
        private final Integer orderId;
        private final String error;

        public PurchaseResult(boolean success, Integer orderId, String error) {
            this.success = success;
            this.orderId = orderId;
            this.error = error;
        }

        public boolean isSuccess() {
            return success;
        }

        public Integer getOrderId() {
            return orderId;
        }

        public String getError() {
            return error;
        }
    }

    public List<Ticket> listForEvent(int eventId) {
        return listTicketsForEvent(eventId);
    }

    public Ticket findById(int ticketId) {
        try (Connection conn = Database.getConnection()) {
            releaseExpiredReservations(conn);
            boolean hasReservationColumns = hasReservationColumns(conn);

            String sql = hasReservationColumns
                    ? "SELECT id, event_id, seat_label, price, status, created, reserved_by_user_id, reserved_until FROM tickets WHERE id = ?"
                    : "SELECT id, event_id, seat_label, price, status, created FROM tickets WHERE id = ?";

            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, ticketId);

                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return mapTicket(rs, hasReservationColumns);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    public boolean markReserved(int ticketId) {
        return reserveTicket(ticketId, 0);
    }

    public boolean markSold(int ticketId) {
        return markTicketAsSold(ticketId);
    }

    public boolean cancelReservation(int ticketId) {
        return cancelReservation(ticketId, 0);
    }

    private boolean updateStatus(int ticketId, String status) {
        String sql = "UPDATE tickets SET status = ?, reserved_by_user_id = NULL, reserved_until = NULL WHERE id = ?";
        String fallbackSql = "UPDATE tickets SET status = ? WHERE id = ?";

        try (Connection conn = Database.getConnection()) {
            boolean hasReservationColumns = hasReservationColumns(conn);
            try (PreparedStatement ps = conn.prepareStatement(hasReservationColumns ? sql : fallbackSql)) {
                ps.setString(1, status);
                ps.setInt(2, ticketId);
                return ps.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Ticket> getAllFiltered(int eventId, String status) {
        List<Ticket> list = new ArrayList<>();

        try (Connection conn = Database.getConnection()) {
            releaseExpiredReservations(conn);
            boolean hasReservationColumns = hasReservationColumns(conn);
            String normalizedFilter = normalizeStatus(status);

            StringBuilder sql = new StringBuilder(
                    hasReservationColumns
                            ? "SELECT id, event_id, seat_label, price, status, created, reserved_by_user_id, reserved_until FROM tickets WHERE 1=1"
                            : "SELECT id, event_id, seat_label, price, status, created FROM tickets WHERE 1=1"
            );

            if (eventId > 0) {
                sql.append(" AND event_id = ?");
            }
            if (normalizedFilter != null && !normalizedFilter.isBlank()) {
                if ("sold".equalsIgnoreCase(normalizedFilter)) {
                    sql.append(" AND LOWER(status) IN ('sold','paid')");
                } else {
                    sql.append(" AND LOWER(status) = ?");
                }
            }
            sql.append(" ORDER BY event_id, id");

            try (PreparedStatement ps = conn.prepareStatement(sql.toString())) {
                int idx = 1;
                if (eventId > 0) {
                    ps.setInt(idx++, eventId);
                }
                if (normalizedFilter != null && !normalizedFilter.isBlank() && !"sold".equalsIgnoreCase(normalizedFilter)) {
                    ps.setString(idx++, normalizedFilter.toLowerCase());
                }

                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        list.add(mapTicket(rs, hasReservationColumns));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    public boolean deleteById(int id) {
        String sql = "DELETE FROM tickets WHERE id = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean markTicketAsSold(int ticketId) {
        String sql = "UPDATE tickets SET status = 'sold' WHERE id = ? AND LOWER(status) NOT IN ('sold', 'paid')";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, ticketId);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean reserveTicket(int ticketId, int userId) {
        try (Connection conn = Database.getConnection()) {
            conn.setAutoCommit(false);
            try {
                releaseExpiredReservations(conn);
                boolean hasReservationColumns = hasReservationColumns(conn);

                if (!hasReservationColumns || userId <= 0) {
                    try (PreparedStatement ps = conn.prepareStatement(
                            "UPDATE tickets SET status = 'reserved' WHERE id = ? AND LOWER(status) = 'available'")) {
                        ps.setInt(1, ticketId);
                        boolean ok = ps.executeUpdate() > 0;
                        conn.commit();
                        return ok;
                    }
                }

                Ticket current = findTicketForUpdate(conn, ticketId, true);
                if (current == null) {
                    conn.rollback();
                    return false;
                }

                String normalizedStatus = current.getNormalizedStatus();
                boolean canReserve = "available".equals(normalizedStatus)
                        || ("reserved".equals(normalizedStatus)
                        && current.getReservedByUserId() != null
                        && current.getReservedByUserId() == userId);

                if (!canReserve) {
                    conn.rollback();
                    return false;
                }

                try (PreparedStatement ps = conn.prepareStatement(
                        "UPDATE tickets SET status = 'reserved', reserved_by_user_id = ?, reserved_until = DATE_ADD(NOW(), INTERVAL ? MINUTE) WHERE id = ?")) {
                    ps.setInt(1, userId);
                    ps.setInt(2, RESERVATION_MINUTES);
                    ps.setInt(3, ticketId);
                    boolean ok = ps.executeUpdate() > 0;
                    conn.commit();
                    return ok;
                }
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
                return false;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public PurchaseResult buyTicket(int ticketId, int userId) {
        if (userId <= 0) {
            return new PurchaseResult(false, null, "Missing user.");
        }

        try (Connection conn = Database.getConnection()) {
            conn.setAutoCommit(false);
            try {
                releaseExpiredReservations(conn);
                boolean hasReservationColumns = hasReservationColumns(conn);
                Ticket current = findTicketForUpdate(conn, ticketId, hasReservationColumns);

                if (current == null) {
                    conn.rollback();
                    return new PurchaseResult(false, null, "Ticket not found.");
                }

                String normalizedStatus = current.getNormalizedStatus();
                if ("sold".equals(normalizedStatus)) {
                    conn.rollback();
                    return new PurchaseResult(false, null, "Ticket already sold.");
                }

                if ("reserved".equals(normalizedStatus) && hasReservationColumns) {
                    Integer ownerId = current.getReservedByUserId();
                    if (ownerId != null && ownerId != userId) {
                        conn.rollback();
                        return new PurchaseResult(false, null, "Ticket reserved by another user.");
                    }
                }

                if (!"available".equals(normalizedStatus) && !"reserved".equals(normalizedStatus)) {
                    conn.rollback();
                    return new PurchaseResult(false, null, "Ticket cannot be purchased.");
                }

                int orderId = insertOrder(conn, userId, current);
                insertBoughtTicket(conn, orderId, current);
                updateTicketAfterPurchase(conn, ticketId, hasReservationColumns);
                conn.commit();
                return new PurchaseResult(true, orderId, null);
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
                return new PurchaseResult(false, null, "Database error.");
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return new PurchaseResult(false, null, "Database connection error.");
        }
    }

    public boolean cancelReservation(int ticketId, int userId) {
        try (Connection conn = Database.getConnection()) {
            conn.setAutoCommit(false);
            try {
                releaseExpiredReservations(conn);
                boolean hasReservationColumns = hasReservationColumns(conn);

                if (!hasReservationColumns || userId <= 0) {
                    try (PreparedStatement ps = conn.prepareStatement(
                            "UPDATE tickets SET status = 'available' WHERE id = ? AND LOWER(status) = 'reserved'")) {
                        ps.setInt(1, ticketId);
                        boolean ok = ps.executeUpdate() > 0;
                        conn.commit();
                        return ok;
                    }
                }

                try (PreparedStatement ps = conn.prepareStatement(
                        "UPDATE tickets SET status = 'available', reserved_by_user_id = NULL, reserved_until = NULL WHERE id = ? AND LOWER(status) = 'reserved' AND reserved_by_user_id = ?")) {
                    ps.setInt(1, ticketId);
                    ps.setInt(2, userId);
                    boolean ok = ps.executeUpdate() > 0;
                    conn.commit();
                    return ok;
                }
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
                return false;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Ticket> listActiveReservationsForUser(int userId) {
        List<Ticket> list = new ArrayList<>();
        if (userId <= 0) {
            return list;
        }

        try (Connection conn = Database.getConnection()) {
            releaseExpiredReservations(conn);
            boolean hasReservationColumns = hasReservationColumns(conn);
            if (!hasReservationColumns) {
                return list;
            }

            String sql = "SELECT id, event_id, seat_label, price, status, created, reserved_by_user_id, reserved_until "
                    + "FROM tickets WHERE LOWER(status) = 'reserved' AND reserved_by_user_id = ? ORDER BY reserved_until, id";

            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        list.add(mapTicket(rs, true));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    public List<Ticket> listTicketsForEvent(int eventId) {
        List<Ticket> list = new ArrayList<>();

        try (Connection conn = Database.getConnection()) {
            releaseExpiredReservations(conn);
            boolean hasReservationColumns = hasReservationColumns(conn);

            String sql = hasReservationColumns
                    ? "SELECT id, event_id, seat_label, price, status, created, reserved_by_user_id, reserved_until FROM tickets WHERE event_id = ? ORDER BY id"
                    : "SELECT id, event_id, seat_label, price, status, created FROM tickets WHERE event_id = ? ORDER BY id";

            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, eventId);

                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        list.add(mapTicket(rs, hasReservationColumns));
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    private int insertOrder(Connection conn, int userId, Ticket ticket) throws SQLException {
        String sql = "INSERT INTO orders (user_id, total, status, title) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, userId);
            ps.setDouble(2, ticket.getPrice());
            ps.setString(3, "paid");
            ps.setString(4, buildOrderTitle(ticket));
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    return keys.getInt(1);
                }
            }
        }
        throw new SQLException("Failed to create order.");
    }

    private void insertBoughtTicket(Connection conn, int orderId, Ticket ticket) throws SQLException {
        String sql = "INSERT INTO bought_tickets (order_id, ticket_id, price) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, orderId);
            ps.setInt(2, ticket.getId());
            ps.setDouble(3, ticket.getPrice());
            ps.executeUpdate();
        }
    }

    private void updateTicketAfterPurchase(Connection conn, int ticketId, boolean hasReservationColumns) throws SQLException {
        String sql = hasReservationColumns
                ? "UPDATE tickets SET status = 'sold', reserved_by_user_id = NULL, reserved_until = NULL WHERE id = ?"
                : "UPDATE tickets SET status = 'sold' WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, ticketId);
            ps.executeUpdate();
        }
    }

    private String buildOrderTitle(Ticket ticket) {
        String seat = ticket.getSeatLabel() == null || ticket.getSeatLabel().isBlank()
                ? "ülőhely nélkül"
                : ticket.getSeatLabel();
        return "Online order - " + seat;
    }

    private Ticket findTicketForUpdate(Connection conn, int ticketId, boolean hasReservationColumns) throws SQLException {
        String sql = hasReservationColumns
                ? "SELECT id, event_id, seat_label, price, status, created, reserved_by_user_id, reserved_until FROM tickets WHERE id = ? FOR UPDATE"
                : "SELECT id, event_id, seat_label, price, status, created FROM tickets WHERE id = ? FOR UPDATE";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, ticketId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapTicket(rs, hasReservationColumns);
                }
            }
        }

        return null;
    }

    private int releaseExpiredReservations(Connection conn) throws SQLException {
        if (!hasReservationColumns(conn)) {
            return 0;
        }

        String sql = "UPDATE tickets SET status = 'available', reserved_by_user_id = NULL, reserved_until = NULL "
                + "WHERE LOWER(status) = 'reserved' AND reserved_until IS NOT NULL AND reserved_until < NOW()";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            return ps.executeUpdate();
        }
    }

    private Ticket mapTicket(ResultSet rs, boolean hasReservationColumns) throws SQLException {
        Integer reservedByUserId = null;
        Timestamp reservedUntil = null;

        if (hasReservationColumns) {
            Object reservedByValue = rs.getObject("reserved_by_user_id");
            if (reservedByValue != null) {
                reservedByUserId = ((Number) reservedByValue).intValue();
            }
            reservedUntil = rs.getTimestamp("reserved_until");
        }

        return new Ticket(
                rs.getInt("id"),
                rs.getInt("event_id"),
                rs.getString("seat_label"),
                rs.getDouble("price"),
                normalizeStatus(rs.getString("status")),
                rs.getTimestamp("created"),
                reservedByUserId,
                reservedUntil
        );
    }

    private String normalizeStatus(String status) {
        if (status == null || status.isBlank()) {
            return "available";
        }
        if ("paid".equalsIgnoreCase(status)) {
            return "sold";
        }
        return status.toLowerCase();
    }

    private boolean hasReservationColumns(Connection conn) throws SQLException {
        if (reservationColumnsAvailableCache != null) {
            return reservationColumnsAvailableCache;
        }

        DatabaseMetaData metaData = conn.getMetaData();
        boolean hasReservedBy = hasColumn(metaData, conn.getCatalog(), "tickets", "reserved_by_user_id");
        boolean hasReservedUntil = hasColumn(metaData, conn.getCatalog(), "tickets", "reserved_until");
        reservationColumnsAvailableCache = hasReservedBy && hasReservedUntil;
        return reservationColumnsAvailableCache;
    }

    private boolean hasColumn(DatabaseMetaData metaData, String catalog, String tableName, String columnName) throws SQLException {
        try (ResultSet rs = metaData.getColumns(catalog, null, tableName, columnName)) {
            if (rs.next()) {
                return true;
            }
        }
        try (ResultSet rs = metaData.getColumns(catalog, null, tableName.toUpperCase(), columnName.toUpperCase())) {
            return rs.next();
        }
    }
}
