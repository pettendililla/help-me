# Javítási jegyzék

## Elvégzett stabilizálások
- `JwtUtil` már nem igényel külső `java-jwt` library-t; a projekt a saját HMAC-alapú JWT megoldását használja végig.
- `nbproject/project.properties` merge conflict jelei el lettek távolítva.
- A hibás, gépfüggő Windows classpath hivatkozás (`C:\\Users\...\java-jwt-4.4.0.jar`) ki lett véve.
- A projekt Java 17-re lett egységesítve.
- A `BookingController`, `BookingApi`, `EventController`, `User`, `Booking` kompatibilitási hibái javítva lettek, hogy a projekt újra fordítható legyen.

## Fontos megjegyzés
Ezek elsősorban **stabilizáló javítások**. A hiányzó adatbázis-táblákra (`shows`, `bookings`, `seats`, `weekly_recommendations`) épülő endpointok üzletileg továbbra is félkészek, csak most már a projekt fordítása nincs azonnal eltörve.
