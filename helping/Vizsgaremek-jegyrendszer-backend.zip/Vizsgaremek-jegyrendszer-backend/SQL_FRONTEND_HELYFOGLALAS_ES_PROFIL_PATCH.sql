USE `vizsgaremekticketz`;

-- =========================================================
-- FRONTEND + HELYFOGLALÁS + PROFIL PATCH
-- 1) tickets: userhez kötött foglalás oszlopok
-- 2) orders: személyes adatok + fizetési mód + foglalási kód
-- 3) users: profil mezők (username, phone)
-- 4) demo előadások és ülések a nap/időpont/helyválasztó UI-hoz
-- =========================================================

SET @db_name := DATABASE();

-- tickets.reserved_by_user_id
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE tickets ADD COLUMN reserved_by_user_id INT NULL AFTER created',
    'SELECT 1'
  )
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'tickets' AND COLUMN_NAME = 'reserved_by_user_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- tickets.reserved_until
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE tickets ADD COLUMN reserved_until DATETIME NULL AFTER reserved_by_user_id',
    'SELECT 1'
  )
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'tickets' AND COLUMN_NAME = 'reserved_until'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- orders.customer_name
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE orders ADD COLUMN customer_name VARCHAR(120) NULL AFTER title',
    'SELECT 1'
  )
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'customer_name'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- orders.customer_phone
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE orders ADD COLUMN customer_phone VARCHAR(50) NULL AFTER customer_name',
    'SELECT 1'
  )
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'customer_phone'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- orders.customer_email
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE orders ADD COLUMN customer_email VARCHAR(190) NULL AFTER customer_phone',
    'SELECT 1'
  )
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'customer_email'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- orders.payment_method
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE orders ADD COLUMN payment_method VARCHAR(30) NULL AFTER customer_email',
    'SELECT 1'
  )
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'payment_method'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- orders.reservation_code
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE orders ADD COLUMN reservation_code VARCHAR(40) NULL AFTER payment_method',
    'SELECT 1'
  )
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'orders' AND COLUMN_NAME = 'reservation_code'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- users.username
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE users ADD COLUMN username VARCHAR(100) NULL AFTER name',
    'SELECT 1'
  )
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'users' AND COLUMN_NAME = 'username'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- users.phone
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE users ADD COLUMN phone VARCHAR(50) NULL AFTER username',
    'SELECT 1'
  )
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'users' AND COLUMN_NAME = 'phone'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- reservation_code index
SET @sql := (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE orders ADD INDEX idx_orders_reservation_code (reservation_code)',
    'SELECT 1'
  )
  FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = @db_name AND TABLE_NAME = 'orders' AND INDEX_NAME = 'idx_orders_reservation_code'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- alap adattisztítás
UPDATE tickets SET status = 'sold' WHERE LOWER(status) = 'paid';
UPDATE users SET username = SUBSTRING_INDEX(email, '@', 1) WHERE (username IS NULL OR username = '');

DELIMITER $$

DROP PROCEDURE IF EXISTS ensure_event$$
CREATE PROCEDURE ensure_event(
    IN p_title VARCHAR(200),
    IN p_room VARCHAR(200),
    IN p_type VARCHAR(20),
    IN p_start DATETIME,
    IN p_end DATETIME,
    IN p_seats INT,
    IN p_cinema_id INT,
    IN p_theatre_id INT
)
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM events
        WHERE title = p_title AND type = p_type AND start = p_start
        LIMIT 1
    ) THEN
        INSERT INTO events (title, room, type, start, end, seats, cinema_id, theatre_id, total_tickets)
        VALUES (p_title, p_room, p_type, p_start, p_end, p_seats, p_cinema_id, p_theatre_id, 0);
    END IF;
END$$

DROP PROCEDURE IF EXISTS seed_event_tickets$$
CREATE PROCEDURE seed_event_tickets(
    IN p_title VARCHAR(200),
    IN p_type VARCHAR(20),
    IN p_start DATETIME,
    IN p_price DECIMAL(10,2)
)
BEGIN
    DECLARE v_event_id INT;
    DECLARE v_row_idx INT DEFAULT 1;
    DECLARE v_seat INT DEFAULT 1;
    DECLARE v_row_label CHAR(1);
    DECLARE v_seat_label VARCHAR(20);

    SELECT id INTO v_event_id
    FROM events
    WHERE title = p_title AND type = p_type AND start = p_start
    LIMIT 1;

    IF v_event_id IS NOT NULL THEN
        SET v_row_idx = 1;
        WHILE v_row_idx <= 4 DO
            SET v_row_label = CHAR(64 + v_row_idx);
            SET v_seat = 1;
            WHILE v_seat <= 8 DO
                SET v_seat_label = CONCAT(v_row_label, v_seat);
                IF NOT EXISTS (
                    SELECT 1 FROM tickets WHERE event_id = v_event_id AND seat_label = v_seat_label
                ) THEN
                    INSERT INTO tickets (event_id, seat_label, price, status)
                    VALUES (v_event_id, v_seat_label, p_price, 'available');
                END IF;
                SET v_seat = v_seat + 1;
            END WHILE;
            SET v_row_idx = v_row_idx + 1;
        END WHILE;

        UPDATE events
        SET total_tickets = (SELECT COUNT(*) FROM tickets WHERE event_id = v_event_id)
        WHERE id = v_event_id;
    END IF;
END$$

DROP PROCEDURE IF EXISTS mark_demo_seat$$
CREATE PROCEDURE mark_demo_seat(
    IN p_title VARCHAR(200),
    IN p_type VARCHAR(20),
    IN p_start DATETIME,
    IN p_seat_label VARCHAR(20),
    IN p_status VARCHAR(20)
)
BEGIN
    DECLARE v_event_id INT;

    SELECT id INTO v_event_id
    FROM events
    WHERE title = p_title AND type = p_type AND start = p_start
    LIMIT 1;

    IF v_event_id IS NOT NULL THEN
        UPDATE tickets
        SET status = p_status,
            reserved_by_user_id = NULL,
            reserved_until = NULL
        WHERE event_id = v_event_id AND seat_label = p_seat_label;
    END IF;
END$$

DELIMITER ;

-- =========================================================
-- Demo műsorok több napra / időpontra
-- =========================================================
CALL ensure_event('Joker', '2', 'cinema',  '2026-05-02 18:00:00', '2026-05-02 20:10:00', 32, 1, NULL);
CALL ensure_event('Joker', '2', 'cinema',  '2026-05-03 20:30:00', '2026-05-03 22:40:00', 32, 1, NULL);
CALL ensure_event('Avatar 3', '4', 'cinema', '2026-05-04 17:30:00', '2026-05-04 20:00:00', 32, 1, NULL);
CALL ensure_event('Avatar 3', '4', 'cinema', '2026-05-06 19:00:00', '2026-05-06 21:30:00', 32, 1, NULL);

CALL ensure_event('Az operaház fantomja', '7', 'theatre', '2026-05-02 15:00:00', '2026-05-02 18:00:00', 32, NULL, 1);
CALL ensure_event('Az operaház fantomja', '7', 'theatre', '2026-05-03 19:00:00', '2026-05-03 22:00:00', 32, NULL, 1);
CALL ensure_event('Az operaház fantomja', '7', 'theatre', '2026-05-04 19:00:00', '2026-05-04 22:00:00', 32, NULL, 1);
CALL ensure_event('Hamilton', '10', 'theatre', '2026-05-06 18:00:00', '2026-05-06 21:00:00', 32, NULL, 1);
CALL ensure_event('Hamilton', '10', 'theatre', '2026-05-08 19:30:00', '2026-05-08 22:30:00', 32, NULL, 1);

-- ülésrend seed
CALL seed_event_tickets('Joker', 'cinema', '2026-05-02 18:00:00', 2990.00);
CALL seed_event_tickets('Joker', 'cinema', '2026-05-03 20:30:00', 2990.00);
CALL seed_event_tickets('Avatar 3', 'cinema', '2026-05-04 17:30:00', 3490.00);
CALL seed_event_tickets('Avatar 3', 'cinema', '2026-05-06 19:00:00', 3490.00);
CALL seed_event_tickets('Az operaház fantomja', 'theatre', '2026-05-02 15:00:00', 4990.00);
CALL seed_event_tickets('Az operaház fantomja', 'theatre', '2026-05-03 19:00:00', 4990.00);
CALL seed_event_tickets('Az operaház fantomja', 'theatre', '2026-05-04 19:00:00', 4990.00);
CALL seed_event_tickets('Hamilton', 'theatre', '2026-05-06 18:00:00', 4590.00);
CALL seed_event_tickets('Hamilton', 'theatre', '2026-05-08 19:30:00', 4590.00);

-- néhány demo foglalt / elkelt hely a piros jelöléshez
CALL mark_demo_seat('Az operaház fantomja', 'theatre', '2026-05-03 19:00:00', 'A1', 'reserved');
CALL mark_demo_seat('Az operaház fantomja', 'theatre', '2026-05-03 19:00:00', 'A2', 'sold');
CALL mark_demo_seat('Az operaház fantomja', 'theatre', '2026-05-03 19:00:00', 'B3', 'reserved');
CALL mark_demo_seat('Joker', 'cinema', '2026-05-03 20:30:00', 'A4', 'sold');
CALL mark_demo_seat('Joker', 'cinema', '2026-05-03 20:30:00', 'B1', 'reserved');

DROP PROCEDURE IF EXISTS ensure_event;
DROP PROCEDURE IF EXISTS seed_event_tickets;
DROP PROCEDURE IF EXISTS mark_demo_seat;
