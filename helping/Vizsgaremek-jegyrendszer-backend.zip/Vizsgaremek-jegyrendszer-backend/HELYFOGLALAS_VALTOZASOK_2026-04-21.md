# Helyfoglalás változások – 2026-04-21

## Mi változott a backendben?

A `tickets` kezelés most már nem csak sima státuszváltás.

### Új foglalási viselkedés
- A foglalás JWT-s felhasználóhoz köthető.
- A foglalás 15 percig él, ha az SQL patch is felment.
- Lejárt foglalásokat a backend automatikusan felszabadítja.
- A saját foglalást ugyanaz a user tudja meghosszabbítani újrafoglalással.
- Más user aktív foglalását nem lehet megvenni vagy törölni.

### Vásárlás logika
- Vásárláskor a backend most már `orders` rekordot is létrehoz.
- Beleírja a kapcsolódó `bought_tickets` rekordot is.
- A ticket státusza egységesen `sold` lesz.

### Státusz normalizálás
- A régi `paid` értéket a backend `sold`-ként kezeli.
- A frontend JSON válaszban ezért konzisztensen `sold` jelenik meg.

## Új / javított endpoint viselkedés

### `GET /api/tickets?eventId=...`
- Opcionális `Authorization` headerrel visszaadja, hogy az adott ticket a jelenlegi useré-e.
- Új mezők a JSON-ban:
  - `reservedByCurrentUser`
  - `reservedUntil` (ha van)

### `GET /api/tickets/my-reservations`
- A belépett user aktív foglalásai.

### `POST /api/tickets/reserve`
- Most már a belépett userhez köti a foglalást.

### `POST /api/tickets/buy`
- Most már rendelést is létrehoz.
- Visszaad egy `orderId` mezőt is.

### `POST /api/tickets/cancel`
- Csak a saját aktív foglalás törölhető.

## Fontos kompatibilitás

A backend úgy lett megírva, hogy a patch nélküli adatbázissal se omoljon össze.
Ebben az esetben:
- userhez kötött foglalás nem lesz teljes értékű,
- lejárati idő sem lesz eltárolva,
- de az alap ticket műveletek továbbra is működnek.

A teljes helyfoglalási viselkedéshez futtasd a `SQL_HELYFOGLALAS_PATCH.sql` fájlt.
