-- Helyfoglalás bővítés patch
-- Cél: userhez kötött, időkorlátos foglalás a tickets táblában
-- Ajánlott futtatási sorrend:
--   1) importáld a vizsgaremekticketz.sql dumpot
--   2) futtasd ezt a patch-et
--   3) indítsd újra a backendet

USE `vizsgaremekticketz`;

ALTER TABLE `tickets`
  ADD COLUMN `reserved_by_user_id` INT NULL AFTER `status`,
  ADD COLUMN `reserved_until` DATETIME NULL AFTER `reserved_by_user_id`;

ALTER TABLE `tickets`
  ADD INDEX `idx_tickets_reserved_state` (`status`, `reserved_until`, `reserved_by_user_id`);

ALTER TABLE `tickets`
  ADD CONSTRAINT `fk_tickets_reserved_by_user`
  FOREIGN KEY (`reserved_by_user_id`) REFERENCES `users`(`id`)
  ON DELETE SET NULL
  ON UPDATE CASCADE;

-- Régi 'paid' státusz egységesítése 'sold'-ra.
UPDATE `tickets`
SET `status` = 'sold'
WHERE LOWER(`status`) = 'paid';
