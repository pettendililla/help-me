const menuBtn = document.getElementById("menuBtn");
const overlay = document.getElementById("menuOverlay");
const miniMenu = document.getElementById("miniMenu");
const avatarInput = document.getElementById("avatarInput");
const avatarPreview = document.getElementById("avatarPreview");
const avatarFallback = document.getElementById("avatarFallback");
const fullNameInput = document.getElementById("fullName");
const userNameInput = document.getElementById("userName");
const phoneInput = document.getElementById("phone");
const emailInput = document.getElementById("email");

function openMenu() {
  overlay.classList.add("show");
  miniMenu.classList.add("show");
  overlay.setAttribute("aria-hidden", "false");
  miniMenu.setAttribute("aria-hidden", "false");
}

function closeMenu() {
  overlay.classList.remove("show");
  miniMenu.classList.remove("show");
  overlay.setAttribute("aria-hidden", "true");
  miniMenu.setAttribute("aria-hidden", "true");
}

menuBtn?.addEventListener("click", () => {
  const isOpen = overlay.classList.contains("show");
  if (isOpen) closeMenu();
  else openMenu();
});

overlay?.addEventListener("click", closeMenu);

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") closeMenu();
});

avatarInput?.addEventListener("change", (e) => {
  const file = e.target.files?.[0];
  if (!file) return;

  const url = URL.createObjectURL(file);
  avatarPreview.src = url;
  avatarPreview.style.display = "block";
  avatarFallback.style.display = "none";
});

document.addEventListener("DOMContentLoaded", async () => {
  if (!Api.isLoggedIn()) {
    window.location.href = "bejelentkezes.html";
    return;
  }

  try {
    const profile = await Api.getProfile();
    fullNameInput.value = profile.fullName || sessionStorage.getItem("name") || "";
    userNameInput.value = profile.userName || localStorage.getItem("profileUserName") || "";
    phoneInput.value = profile.phone || localStorage.getItem("profilePhone") || "";
    emailInput.value = profile.email || sessionStorage.getItem("email") || "";
  } catch (err) {
    console.error(err);
    fullNameInput.value = sessionStorage.getItem("name") || "";
    emailInput.value = sessionStorage.getItem("email") || "";
    userNameInput.value = localStorage.getItem("profileUserName") || "";
    phoneInput.value = localStorage.getItem("profilePhone") || "";
  }
});

document.querySelectorAll(".edit-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    const targetId = btn.getAttribute("data-target");
    const input = document.getElementById(targetId);
    if (!input) return;

    input.disabled = false;
    input.classList.add("is-editing");
    input.focus();

    const val = input.value;
    input.value = "";
    input.value = val;
  });
});

document.querySelectorAll(".data-input").forEach(input => {
  input.addEventListener("blur", async () => {
    input.disabled = true;
    input.classList.remove("is-editing");

    const payload = {
      fullName: fullNameInput.value.trim(),
      userName: userNameInput.value.trim(),
      phone: phoneInput.value.trim(),
      email: emailInput.value.trim()
    };

    localStorage.setItem("profileUserName", payload.userName);
    localStorage.setItem("profilePhone", payload.phone);

    try {
      const saved = await Api.saveProfile(payload);
      sessionStorage.setItem("name", saved.fullName || payload.fullName);
      sessionStorage.setItem("email", saved.email || payload.email);
      userNameInput.value = saved.userName || payload.userName;
      phoneInput.value = saved.phone || payload.phone;
      fullNameInput.value = saved.fullName || payload.fullName;
      emailInput.value = saved.email || payload.email;
    } catch (err) {
      console.error(err);
    }
  });
});
