document.addEventListener("DOMContentLoaded", () => {
  const raw = sessionStorage.getItem("bookingSuccess");
  if (!raw) {
    window.location.href = "mozi.html";
    return;
  }

  const data = JSON.parse(raw);
  document.getElementById("reservationCode").innerText = data.reservationCode || data.orderId || "-";
  document.getElementById("successSummary").innerHTML = `
    <div><strong>Előadás:</strong> ${data.title || "-"}</div>
    <div><strong>Időpont:</strong> ${formatDateTime(data.start)}</div>
    <div><strong>Helyek:</strong> ${(data.seats || []).join(", ")}</div>
    <div><strong>Fizetés:</strong> Helyszínen, a pénztárban</div>
  `;
});

function formatDateTime(dateString) {
  if (!dateString) return "-";
  const date = new Date(dateString);
  return date.toLocaleString("hu-HU", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  });
}
