document.addEventListener("DOMContentLoaded", () => {
  const draftRaw = sessionStorage.getItem("bookingDraft");
  if (!draftRaw) {
    alert("Nincs kiválasztott foglalás.");
    window.location.href = "mozi.html";
    return;
  }

  const draft = JSON.parse(draftRaw);
  const summary = document.getElementById("bookingSummary");
  const showTitle = document.getElementById("showTitle");
  const form = document.getElementById("bookingForm");
  const message = document.getElementById("message");
  const nameInput = document.getElementById("name");
  const phoneInput = document.getElementById("phone");
  const emailInput = document.getElementById("email");

  showTitle.innerText = draft.title;
  summary.innerHTML = `
    <div><strong>Időpont:</strong> ${formatDateTime(draft.start)}</div>
    <div><strong>Terem:</strong> ${draft.room || "-"}</div>
    <div><strong>Helyek:</strong> ${(draft.seats || []).join(", ")}</div>
    <div><strong>Összesen:</strong> ${Number(draft.total || 0).toFixed(0)} Ft</div>
  `;

  nameInput.value = sessionStorage.getItem("name") || "";
  emailInput.value = sessionStorage.getItem("email") || "";
  phoneInput.value = localStorage.getItem("profilePhone") || "";

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    message.innerText = "";

    if (!Api.isLoggedIn()) {
      alert("A foglaláshoz előbb jelentkezz be.");
      window.location.href = "bejelentkezes.html";
      return;
    }

    if (!nameInput.value.trim() || !phoneInput.value.trim() || !emailInput.value.trim()) {
      message.innerText = "Minden mező kitöltése kötelező.";
      return;
    }

    try {
      const result = await Api.createBooking({
        eventId: draft.eventId,
        ticketIds: draft.ticketIds,
        fullName: nameInput.value.trim(),
        phone: phoneInput.value.trim(),
        email: emailInput.value.trim(),
        paymentMethod: "onsite"
      });

      localStorage.setItem("profilePhone", phoneInput.value.trim());
      sessionStorage.setItem("bookingSuccess", JSON.stringify({
        ...result,
        ...draft,
        fullName: nameInput.value.trim(),
        phone: phoneInput.value.trim(),
        email: emailInput.value.trim()
      }));
      sessionStorage.removeItem("bookingDraft");
      window.location.href = "foglalas_sikeres.html";
    } catch (err) {
      console.error(err);
      message.innerText = "Hiba: " + err.message;
    }
  });
});

function formatDateTime(dateString) {
  const date = new Date(dateString);
  return date.toLocaleString("hu-HU", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  });
}
