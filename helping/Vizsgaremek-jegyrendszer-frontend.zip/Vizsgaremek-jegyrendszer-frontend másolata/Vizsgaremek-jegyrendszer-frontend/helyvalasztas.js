let matchingEvents = [];
let ticketsByEvent = new Map();
let selectedDay = null;
let selectedEvent = null;
let selectedTickets = [];

document.addEventListener("DOMContentLoaded", async () => {
  const params = new URLSearchParams(window.location.search);
  const title = params.get("title");
  const type = params.get("type");

  if (!title || !type) {
    document.getElementById("seatMessage").innerText = "Hiányzó előadás adat.";
    return;
  }

  document.getElementById("showTitle").innerText = decodeURIComponent(title);

  try {
    const events = await Api.getEvents();
    matchingEvents = events
      .filter(event => event.title === decodeURIComponent(title) && String(event.type).toLowerCase() === String(type).toLowerCase())
      .sort((a, b) => new Date(a.start) - new Date(b.start));

    if (!matchingEvents.length) {
      document.getElementById("seatMessage").innerText = "Ehhez az előadáshoz most nincs elérhető időpont.";
      return;
    }

    const ticketResponses = await Promise.all(
      matchingEvents.map(event => Api.getTickets(event.id).catch(() => []))
    );

    matchingEvents = matchingEvents.map((event, index) => {
      const tickets = ticketResponses[index] || [];
      ticketsByEvent.set(event.id, tickets);
      event.availableCount = tickets.filter(ticket => ticket.status === "available").length;
      return event;
    }).filter(event => event.availableCount > 0);

    if (!matchingEvents.length) {
      document.getElementById("seatMessage").innerText = "Minden időpont betelt.";
      return;
    }

    renderDays();
  } catch (err) {
    console.error(err);
    document.getElementById("seatMessage").innerText = "Nem sikerült betölteni a helyválasztást.";
  }

  document.getElementById("continueBtn").addEventListener("click", continueToBooking);
});

function renderDays() {
  const dayButtons = document.getElementById("dayButtons");
  const dayMap = new Map();

  matchingEvents.forEach(event => {
    const key = formatDayKey(event.start);
    if (!dayMap.has(key)) {
      dayMap.set(key, event.start);
    }
  });

  dayButtons.innerHTML = "";
  Array.from(dayMap.entries()).forEach(([dayKey, rawDate], index) => {
    const btn = document.createElement("button");
    btn.className = "schedule-btn" + (index === 0 ? " active" : "");
    btn.innerHTML = `<span>${formatWeekday(rawDate)}</span><small>${formatDisplayDate(rawDate)}</small>`;
    btn.onclick = () => selectDay(dayKey, btn);
    dayButtons.appendChild(btn);
    if (index === 0) selectedDay = dayKey;
  });

  renderTimes();
}

function selectDay(dayKey, btn) {
  selectedDay = dayKey;
  document.querySelectorAll("#dayButtons .schedule-btn").forEach(button => button.classList.remove("active"));
  btn.classList.add("active");
  renderTimes();
}

function renderTimes() {
  const timeButtons = document.getElementById("timeButtons");
  const eventsForDay = matchingEvents.filter(event => formatDayKey(event.start) === selectedDay);
  timeButtons.innerHTML = "";
  selectedTickets = [];
  updateSelectedSummary();
  document.getElementById("continueBtn").disabled = true;

  eventsForDay.forEach((event, index) => {
    const btn = document.createElement("button");
    btn.className = "schedule-btn" + (index === 0 ? " active" : "");
    btn.innerHTML = `<span>${formatTime(event.start)}</span><small>${event.availableCount} szabad</small>`;
    btn.onclick = () => selectTime(event, btn);
    timeButtons.appendChild(btn);
    if (index === 0) selectedEvent = event;
  });

  if (!eventsForDay.length) {
    document.getElementById("seatMessage").innerText = "Erre a napra nincs szabad időpont.";
    document.getElementById("seats").innerHTML = "";
    return;
  }

  renderSeats(selectedEvent);
}

function selectTime(event, btn) {
  selectedEvent = event;
  selectedTickets = [];
  document.querySelectorAll("#timeButtons .schedule-btn").forEach(button => button.classList.remove("active"));
  btn.classList.add("active");
  updateSelectedSummary();
  renderSeats(event);
}

function renderSeats(event) {
  const container = document.getElementById("seats");
  const seatMessage = document.getElementById("seatMessage");
  const roomInfo = document.getElementById("roomInfo");
  const tickets = ticketsByEvent.get(event.id) || [];

  roomInfo.innerText = event.room || "-";
  selectedTickets = [];
  updateSelectedSummary();
  document.getElementById("continueBtn").disabled = true;

  if (!tickets.length) {
    container.innerHTML = "";
    seatMessage.innerText = "Ehhez az időponthoz nincs seat adat.";
    return;
  }

  seatMessage.innerText = `${formatDisplayDate(event.start)} • ${formatTime(event.start)}`;
  container.innerHTML = "";

  const grouped = new Map();
  tickets.forEach(ticket => {
    const match = String(ticket.seatLabel || "").match(/^([A-Za-z]+)(\d+)$/);
    const row = match ? match[1].toUpperCase() : "?";
    const seatNumber = match ? Number(match[2]) : ticket.id;
    if (!grouped.has(row)) grouped.set(row, []);
    grouped.get(row).push({ ...ticket, seatNumber });
  });

  Array.from(grouped.keys()).sort().forEach(row => {
    const rowWrap = document.createElement("div");
    rowWrap.className = "seat-row";

    const label = document.createElement("div");
    label.className = "row-label";
    label.innerText = row;
    rowWrap.appendChild(label);

    const rowSeats = document.createElement("div");
    rowSeats.className = "row-seats";

    grouped.get(row)
      .sort((a, b) => a.seatNumber - b.seatNumber)
      .forEach(ticket => {
        const seat = document.createElement("div");
        seat.className = "seat";
        seat.innerText = ticket.seatLabel;

        if (ticket.status === "reserved") {
          seat.classList.add("taken");
        } else if (ticket.status === "sold") {
          seat.classList.add("sold");
        }

        seat.onclick = () => toggleSeat(ticket, seat);
        rowSeats.appendChild(seat);
      });

    rowWrap.appendChild(rowSeats);
    container.appendChild(rowWrap);
  });
}

function toggleSeat(ticket, seatEl) {
  if (ticket.status !== "available") return;

  const existingIndex = selectedTickets.findIndex(item => item.id === ticket.id);
  if (existingIndex >= 0) {
    selectedTickets.splice(existingIndex, 1);
    seatEl.classList.remove("selected");
  } else {
    selectedTickets.push(ticket);
    seatEl.classList.add("selected");
  }

  updateSelectedSummary();
  document.getElementById("continueBtn").disabled = selectedTickets.length === 0;
}

function updateSelectedSummary() {
  const summary = document.getElementById("selectedSummary");
  if (!selectedTickets.length) {
    summary.innerText = "Még nincs kiválasztott hely.";
    return;
  }

  const seats = selectedTickets.map(ticket => ticket.seatLabel).join(", ");
  const total = selectedTickets.reduce((sum, ticket) => sum + Number(ticket.price || 0), 0);
  summary.innerText = `Kiválasztott helyek: ${seats} • Összesen: ${total.toFixed(0)} Ft`;
}

function continueToBooking() {
  if (!selectedEvent || !selectedTickets.length) {
    alert("Válassz legalább egy helyet.");
    return;
  }

  const draft = {
    eventId: selectedEvent.id,
    title: selectedEvent.title,
    type: selectedEvent.type,
    room: selectedEvent.room,
    start: selectedEvent.start,
    ticketIds: selectedTickets.map(ticket => ticket.id),
    seats: selectedTickets.map(ticket => ticket.seatLabel),
    total: selectedTickets.reduce((sum, ticket) => sum + Number(ticket.price || 0), 0)
  };

  sessionStorage.setItem("bookingDraft", JSON.stringify(draft));
  window.location.href = "jegyfoglalas.html";
}

function formatDayKey(dateString) {
  const date = new Date(dateString);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function formatWeekday(dateString) {
  return new Date(dateString).toLocaleDateString("hu-HU", { weekday: "short" });
}

function formatDisplayDate(dateString) {
  return new Date(dateString).toLocaleDateString("hu-HU", { month: "2-digit", day: "2-digit" });
}

function formatTime(dateString) {
  return new Date(dateString).toLocaleTimeString("hu-HU", { hour: "2-digit", minute: "2-digit" });
}
