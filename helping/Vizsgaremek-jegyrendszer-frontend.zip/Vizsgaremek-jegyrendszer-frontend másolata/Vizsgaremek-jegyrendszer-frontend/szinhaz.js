const THEATRE_META = {
  "Az operaház fantomja": {
    image: "images/operahaz.png",
    description: "Romantikus, drámai és látványos zenés előadás több időpontban."
  },
  "Hamilton": {
    image: "images/hamilton.png",
    description: "Népszerű musical lendületes zenével és modern színpadi világgal."
  }
};

let theatres = [];
let currentIndex = 0;

document.addEventListener("DOMContentLoaded", async () => {
  try {
    const events = await Api.getEvents();
    const theatreMap = new Map();

    events
      .filter(event => String(event.type).toLowerCase() === "theatre")
      .forEach(event => {
        if (!theatreMap.has(event.title)) {
          theatreMap.set(event.title, {
            title: event.title,
            type: "theatre",
            meta: THEATRE_META[event.title] || {
              image: "images/operahaz.png",
              description: "Elérhető előadás több napon és időpontban."
            }
          });
        }
      });

    theatres = Array.from(theatreMap.values());

    if (!theatres.length) {
      alert("Nincs elérhető színházi előadás.");
      return;
    }

    showTheatre(currentIndex);
    document.getElementById("nextBtn").onclick = nextTheatre;
    document.getElementById("prevBtn").onclick = prevTheatre;
  } catch (err) {
    console.error(err);
    alert("Hiba a színház oldalon.");
  }
});

function showTheatre(index) {
  const item = theatres[index];
  document.getElementById("title").innerText = item.title;
  document.getElementById("desc").innerText = item.meta.description;
  document.getElementById("poster").src = item.meta.image;
  document.getElementById("buyBtn").href =
    `helyvalasztas.html?type=${encodeURIComponent(item.type)}&title=${encodeURIComponent(item.title)}`;
}

function nextTheatre() {
  currentIndex = (currentIndex + 1) % theatres.length;
  showTheatre(currentIndex);
}

function prevTheatre() {
  currentIndex = (currentIndex - 1 + theatres.length) % theatres.length;
  showTheatre(currentIndex);
}
