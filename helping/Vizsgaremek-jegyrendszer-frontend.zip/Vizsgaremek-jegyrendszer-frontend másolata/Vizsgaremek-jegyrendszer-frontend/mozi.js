const MOVIE_META = {
  "Joker": {
    image: "images/joker.png",
    description: "Sötét hangulatú dráma egy ikonikus gonosztevő felemelkedéséről."
  },
  "Jurassic World": {
    image: "images/terminator.png",
    description: "Látványos kalandfilm dinoszauruszokkal, akcióval és feszültséggel."
  },
  "Avatar 3": {
    image: "images/igyneveldasarkanyod.png",
    description: "Nagyívű sci-fi kaland lenyűgöző látványvilággal és érzelmes történettel."
  }
};

let movies = [];
let currentIndex = 0;

document.addEventListener("DOMContentLoaded", async () => {
  try {
    const events = await Api.getEvents();
    const movieMap = new Map();

    events
      .filter(event => String(event.type).toLowerCase() === "cinema")
      .forEach(event => {
        if (!movieMap.has(event.title)) {
          movieMap.set(event.title, {
            title: event.title,
            type: "cinema",
            meta: MOVIE_META[event.title] || {
              image: "images/joker.png",
              description: "Elérhető vetítések több időpontban."
            }
          });
        }
      });

    movies = Array.from(movieMap.values());

    if (!movies.length) {
      alert("Nincs elérhető mozi esemény.");
      return;
    }

    showMovie(currentIndex);
    document.getElementById("nextBtn").onclick = nextMovie;
    document.getElementById("prevBtn").onclick = prevMovie;
  } catch (err) {
    console.error(err);
    alert("Hiba a mozi oldalon.");
  }
});

function showMovie(index) {
  const item = movies[index];
  document.getElementById("title").innerText = item.title;
  document.getElementById("desc").innerText = item.meta.description;
  document.getElementById("poster").src = item.meta.image;
  document.getElementById("buyBtn").href =
    `helyvalasztas.html?type=${encodeURIComponent(item.type)}&title=${encodeURIComponent(item.title)}`;
}

function nextMovie() {
  currentIndex = (currentIndex + 1) % movies.length;
  showMovie(currentIndex);
}

function prevMovie() {
  currentIndex = (currentIndex - 1 + movies.length) % movies.length;
  showMovie(currentIndex);
}
