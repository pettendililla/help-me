document.addEventListener("DOMContentLoaded", async () => {
  const menuBtn = document.getElementById("menuBtn");
  const overlay = document.getElementById("menuOverlay");
  const miniMenu = document.getElementById("miniMenu");
  const logoutLink = document.getElementById("logoutLink");
  const list = document.getElementById("bookingsList");

  menuBtn?.addEventListener("click", () => {
    overlay.classList.toggle("show");
    miniMenu.classList.toggle("show");
  });

  overlay?.addEventListener("click", () => {
    overlay.classList.remove("show");
    miniMenu.classList.remove("show");
  });

  logoutLink?.addEventListener("click", (event) => {
    event.preventDefault();
    Api.logout("bejelentkezes.html");
  });

  if (!Api.isLoggedIn()) {
    list.innerHTML = '<div class="empty-state">A foglalások megtekintéséhez jelentkezz be.</div>';
    return;
  }

  try {
    const bookings = await Api.getMyBookings();
    if (!bookings.length) {
      list.innerHTML = '<div class="empty-state">Még nincs mentett foglalásod.</div>';
      return;
    }

    list.innerHTML = bookings.map(booking => `
      <div class="ticket-card">
        <div class="ticket-content">
          <p><strong>Előadás:</strong> ${escapeHtml(booking.eventTitle || '-')}</p>
          <p><strong>Időpont:</strong> ${formatDateTime(booking.eventStart)}</p>
          <p><strong>Hely:</strong> ${escapeHtml(booking.seats || '-')}</p>
          <p><strong>Terem:</strong> ${escapeHtml(booking.room || '-')}</p>
          <p><strong>Fizetés:</strong> ${formatPayment(booking.paymentMethod)}</p>
          <p><strong>Státusz:</strong> ${formatStatus(booking.status)}</p>
          <p><strong>Összeg:</strong> ${Number(booking.total || 0).toFixed(0)} Ft</p>
          <p><strong>Foglalási szám:</strong> ${escapeHtml(String(booking.reservationCode || booking.orderId || '-'))}</p>
        </div>
      </div>
    `).join('');
  } catch (err) {
    console.error(err);
    list.innerHTML = `<div class="empty-state">Hiba a foglalások lekérésekor: ${escapeHtml(err.message)}</div>`;
  }
});

function formatStatus(status) {
  if (!status) return '-';
  if (status === 'reserved') return 'Foglalva';
  if (status === 'sold' || status === 'paid') return 'Kifizetve';
  return status;
}

function formatPayment(method) {
  if (!method) return 'Helyszíni fizetés';
  return method === 'onsite' || method === 'cash' ? 'Helyszíni fizetés' : method;
}

function formatDateTime(dateString) {
  if (!dateString || dateString === 'null') return '-';
  const date = new Date(dateString);
  return date.toLocaleString('hu-HU', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}
