(() => {
  const BASE_URL = "http://localhost:9090";

  function getToken() {
    return localStorage.getItem("token");
  }

  function isLoggedIn() {
    return !!getToken();
  }

  function getRole() {
    return localStorage.getItem("role");
  }

  function getName() {
    return localStorage.getItem("name");
  }

  function getEmail() {
    return localStorage.getItem("email");
  }

  function logout(redirectTo = "bejelentkezes.html") {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    localStorage.removeItem("userId");
    localStorage.removeItem("name");
    localStorage.removeItem("email");

    sessionStorage.removeItem("bookingDraft");
    sessionStorage.removeItem("bookingSuccess");

    window.location.href = redirectTo;
  }

  async function apiRequest(path, { method = "GET", body = null, auth = true, optionalAuth = false } = {}) {
    const headers = { "Content-Type": "application/json" };
    const token = getToken();

    if (auth) {
      if (!token) throw new Error("Bejelentkezés szükséges");
      headers["Authorization"] = "Bearer " + token;
    } else if (optionalAuth && token) {
      headers["Authorization"] = "Bearer " + token;
    }

    const res = await fetch(BASE_URL + path, {
      method,
      mode: "cors",
      headers,
      body: body ? JSON.stringify(body) : null
    });

    const text = await res.text();
    let data = null;
    try {
      data = text ? JSON.parse(text) : null;
    } catch {
      data = text;
    }

    if (!res.ok) {
      const msg = (data && data.error) ? data.error : ("HTTP " + res.status);
      throw new Error(msg);
    }

    return data;
  }

  async function login(email, password) {
    const data = await apiRequest("/api/auth/login", {
      method: "POST",
      body: { email, password },
      auth: false
    });

    localStorage.setItem("token", data.token);
    localStorage.setItem("role", data.role);
    localStorage.setItem("userId", String(data.userId));
    localStorage.setItem("name", data.name);
    localStorage.setItem("email", data.email);

    return data;
  }

  async function register(name, email, password) {
    return apiRequest("/api/auth/register", {
      method: "POST",
      body: { name, email, password },
      auth: false
    });
  }

  async function getEvents() {
    return apiRequest("/api/events", { auth: false });
  }

  async function getMovies() {
    return apiRequest("/api/movies", { auth: false });
  }

  async function getTheatres() {
    return apiRequest("/api/theatres", { auth: false });
  }

  async function getTickets(eventId) {
    return apiRequest(`/api/tickets?eventId=${encodeURIComponent(eventId)}`, {
      auth: false,
      optionalAuth: true
    });
  }

  async function reserveTicket(ticketId) {
    return apiRequest("/api/tickets/reserve", {
      method: "POST",
      body: { ticketId },
      auth: true
    });
  }

  async function buyTicket(ticketId) {
    return apiRequest("/api/tickets/buy", {
      method: "POST",
      body: { ticketId },
      auth: true
    });
  }

  async function cancelTicket(ticketId) {
    return apiRequest("/api/tickets/cancel", {
      method: "POST",
      body: { ticketId },
      auth: true
    });
  }

  async function getProfile() {
    return apiRequest("/api/profile", { auth: true });
  }

  async function saveProfile(data) {
    return apiRequest("/api/profile", {
      method: "PUT",
      body: data,
      auth: true
    });
  }

  async function createBooking(data) {
    return apiRequest("/api/bookings", {
      method: "POST",
      body: data,
      auth: true
    });
  }

  async function getMyBookings() {
    return apiRequest("/api/bookings/my", { auth: true });
  }

  async function getMyReservations() {
    return apiRequest("/api/tickets/my-reservations", { auth: true });
  }

  async function adminDeleteUser(id) {
    return apiRequest(`/api/admin/users?id=${encodeURIComponent(id)}`, {
      method: "DELETE",
      auth: true
    });
  }

  async function getWeekly() {
    return apiRequest("/api/weekly", { auth: false });
  }

  async function getShows(type) {
    return apiRequest(`/api/shows?type=${encodeURIComponent(type)}`, { auth: false });
  }

  window.Api = {
    isLoggedIn,
    getRole,
    getName,
    getEmail,
    logout,
    login,
    register,
    getEvents,
    getMovies,
    getTheatres,
    getTickets,
    reserveTicket,
    buyTicket,
    cancelTicket,
    getProfile,
    saveProfile,
    createBooking,
    getMyBookings,
    getMyReservations,
    adminDeleteUser,
    getWeekly,
    getShows,
    apiRequest
  };
})();