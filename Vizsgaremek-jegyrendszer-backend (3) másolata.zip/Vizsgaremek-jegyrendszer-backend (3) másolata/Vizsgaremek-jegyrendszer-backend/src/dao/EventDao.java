package dao;



import model.Event;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.MovieDto;

public class EventDao {

    public Event findById(int id) {
        String sql = "SELECT id, title, room, type, start, end, seats, cinema_id, theatre_id FROM events WHERE id = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapEvent(rs);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Event> getAll() {
        String sql = "SELECT id, title, room, type, start, end, seats, cinema_id, theatre_id FROM events ORDER BY id";
        List<Event> list = new ArrayList<>();

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) list.add(mapEvent(rs));

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Event> getByType(String type) {
        String sql = "SELECT id, title, room, type, start, end, seats, cinema_id, theatre_id FROM events WHERE type = ? ORDER BY id";
        List<Event> list = new ArrayList<>();

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, type);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapEvent(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    
  

   public boolean deleteById(int id) {
    String sql = "DELETE FROM events WHERE id = ?";
    try (Connection conn = Database.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setInt(1, id);
        return ps.executeUpdate() > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}

    private Event mapEvent(ResultSet rs) throws SQLException {
        return new Event(
                rs.getInt("id"),
                rs.getString("title"),
                rs.getString("room"),
                rs.getString("type"),
                rs.getTimestamp("start"),
                rs.getTimestamp("end"),
                rs.getInt("seats"),
                (Integer) rs.getObject("cinema_id"),
                (Integer) rs.getObject("theatre_id")
        );
    }
    
    public boolean insertEvent(String title, String type, int room, int seats, String start, String end) {
    String sql = "INSERT INTO events (title, room, type, start, end, seats) VALUES (?, ?, ?, ?, ?, ?)";

    try (Connection conn = Database.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setString(1, title);
        ps.setInt(2, room);
        ps.setString(3, type); // "cinema" / "theatre"
        ps.setString(4, start);
        ps.setString(5, end);
        ps.setInt(6, seats);

        return ps.executeUpdate() > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
 public List<MovieDto> getCinemaMovies() {
    String sql =
        "SELECT e.id, e.title, e.start, e.end, e.room, " +
        "       mi.genre, mi.writer, mi.length_min " +
        "FROM events e " +
        "LEFT JOIN movie_info mi ON mi.event_id = e.id " +
        "WHERE e.type = 'cinema' " +
        "ORDER BY e.start";

    List<MovieDto> list = new ArrayList<>();

    try (Connection conn = Database.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            list.add(new MovieDto(
                rs.getInt("id"),
                rs.getString("title"),
                rs.getString("genre"),
                rs.getString("writer"),
                rs.getInt("length_min"),
                rs.getString("start"),
                rs.getString("end"),
                String.valueOf(rs.getInt("room"))
            ));
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return list;
}}

    
