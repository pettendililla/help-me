package dao;

import model.Ticket;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TicketDao {

    public List<Ticket> listForEvent(int eventId) {
        List<Ticket> list = new ArrayList<>();
        String sql = "SELECT id, event_id, seat_label, price, status, created " +
                     "FROM tickets WHERE event_id = ? ORDER BY id";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, eventId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapTicket(rs));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }


    public boolean markReserved(int ticketId) {
        return updateStatus(ticketId, "reserved");
    }

    public boolean markSold(int ticketId) {
        return updateStatus(ticketId, "sold");
    }

    public boolean cancelReservation(int ticketId) {
        return updateStatus(ticketId, "available");
    }

    private boolean updateStatus(int ticketId, String status) {
        String sql = "UPDATE tickets SET status = ? WHERE id = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, status);
            ps.setInt(2, ticketId);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

   
    public List<Ticket> getAllFiltered(int eventId, String status) {
        List<Ticket> list = new ArrayList<>();

        StringBuilder sql = new StringBuilder(
                "SELECT id, event_id, seat_label, price, status, created FROM tickets WHERE 1=1"
        );

        if (eventId > 0) sql.append(" AND event_id = ?");
        if (status != null && !status.isBlank()) sql.append(" AND status = ?");
        sql.append(" ORDER BY event_id, id");

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {

            int idx = 1;
            if (eventId > 0) ps.setInt(idx++, eventId);
            if (status != null && !status.isBlank()) ps.setString(idx++, status);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapTicket(rs));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

  
    public boolean deleteById(int id) {
        String sql = "DELETE FROM tickets WHERE id = ?";

        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

  
    private Ticket mapTicket(ResultSet rs) throws SQLException {
        return new Ticket(
                rs.getInt("id"),
                rs.getInt("event_id"),
                rs.getString("seat_label"),
                rs.getDouble("price"),
                rs.getString("status"),
                rs.getTimestamp("created")
        );
    }

    public boolean markTicketAsSold(int ticketId) {
    String sql = "UPDATE tickets SET status = 'sold' WHERE id = ? AND status <> 'sold'";

    try (Connection conn = Database.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setInt(1, ticketId);
        return ps.executeUpdate() > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}

    public boolean reserveTicket(int ticketId) {
    String sql = "UPDATE tickets SET status = 'reserved' WHERE id = ? AND status = 'available'";

    try (Connection conn = Database.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setInt(1, ticketId);
        return ps.executeUpdate() > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}

    public List<Ticket> listTicketsForEvent(int eventId) {
    List<Ticket> list = new ArrayList<>();

    String sql = "SELECT id, event_id, seat_label, price, status, created " +
                 "FROM tickets WHERE event_id = ? ORDER BY id";

    try (Connection conn = Database.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setInt(1, eventId);

        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Ticket t = new Ticket(
                        rs.getInt("id"),
                        rs.getInt("event_id"),
                        rs.getString("seat_label"),
                        rs.getDouble("price"),
                        rs.getString("status"),
                        rs.getTimestamp("created")   // <-- ez Timestamp (jó)
                );
                list.add(t);
            }
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return list;
}
}